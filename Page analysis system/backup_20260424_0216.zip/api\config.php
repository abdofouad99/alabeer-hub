<?php
// ============================================================
// api/config.php — إعدادات النظام الكاملة v3.0
// ============================================================

// ─── Helper: اختيار Gemini Key تلقائياً بالتناوب ────────────
if (!function_exists('getGeminiKey')) {
    function getGeminiKey(array $cfg): string {
        $keys = $cfg['apis']['gemini_keys'] ?? [];
        if (empty($keys)) return '';
        return $keys[time() % count($keys)];
    }
}

// ─── Helper: اختيار Apify Token تلقائياً بالتناوب ───────────
if (!function_exists('getApifyToken')) {
    function getApifyToken(array $cfg): string {
        $tokens = $cfg['apis']['apify_tokens'] ?? [];
        if (empty($tokens)) return '';
        return $tokens[time() % count($tokens)];
    }
}

return [

    // ─── قاعدة البيانات (Local by Flywheel) ─────────────────
    'db' => [
        'host'    => '127.0.0.1:10006',   // Port الصحيح لـ Local by Flywheel
        'name'    => 'local',
        'user'    => 'root',
        'pass'    => 'root',
        'charset' => 'utf8mb4',
    ],

    // ─── Supabase (للمزامنة والنسخ الاحتياطي) ───────────────
    'supabase' => [
        'url'        => 'https://gukrhviolkjoabxtcsum.supabase.co',
        'anon_key'   => 'sb_publishable_OITkitMRA0CjavH1ubr1gA_ejL3gAVs',
        'secret_key' => 'sb_secret_k9Wq6o4JlM3CUju4y4hSnA_EH6Wbqaq',
        'db_url'     => 'postgresql://postgres.gukrhviolkjoabxtcsum:abdo770681605@aws-1-ap-southeast-2.pooler.supabase.com:6543/postgres?pgbouncer=true',
    ],

    // ─── Admin ───────────────────────────────────────────────
    'admin' => [
        'session_name'     => 'alabeer_admin_sess',
        'session_lifetime' => 7200,
    ],

    // ─── App Settings ────────────────────────────────────────
    'app' => [
        'wa_number' => '967739537053',
        'version'   => '3.0',
        'name'      => 'بصمة النمو — تحليل الصفحات',
    ],

    // ─── API Keys ────────────────────────────────────────────
    'apis' => [

        // ── Gemini AI (مدوّر تلقائي بين 6 مفاتيح) ───────────
        'gemini_keys' => [
            'AIzaSyAuJfA9GqHcBSrXy7AR4Ou-P5Uv8xL3dFI',
            'AIzaSyAfgxIKrsQ0J3u3MRhookW2jChPAWGNyOY',
            'AIzaSyC13pkFiRPlxYgGNR5jx1slFU374GBZAI0',
            'AIzaSyA1coGqz_bGT6E04edOW1yf80cH6k8GotE',
            'AIzaSyBZrRdSHcsUneBMcGJ9o939uwV7Ogzc_UQ',
            'AIzaSyCJnYwKXPrqrq-107Y2d3wpHGu7_6AQEms',
        ],
        // المفتاح الأساسي (يُختار تلقائياً من القائمة)
        'gemini_key'   => 'AIzaSyAuJfA9GqHcBSrXy7AR4Ou-P5Uv8xL3dFI',
        'gemini_model' => 'gemini-2.0-flash',

        // ── Google PageSpeed (يعمل بدون مفتاح بحد محدود) ────
        // يستخدم نفس Gemini domain key
        'google_pagespeed_key' => '',  // اتركه فارغاً = مجاني بدون حد عالٍ

        // ── Facebook Graph API ───────────────────────────────
        'facebook_access_token' => 'EAAS0RMdfHpoBRJmX2CdbXS3VDEAoZCDBHKlnn5iu0E9LVqkfuQlDn5ZAafzKz8OVfI72ZC6mZB6vVMITMZBMFyWds9gRGC2qhZBTFWX1ow00NZCZBnZAZAhstPL5KoZAPFuzhABXLV8jZCNYyZCkZBsPJGEvHvHAUQGXwDI0UNZBgF4aijE0igUjDTnkNLC3uIjAgMTqswzyhNdYsCo4W2BLZAQZBJrJ7kEcrwMy2ZB5Ynlm8EU2oXHJrDAXQ8QTPzMDMbyac3iXftibNoZBNZCCUZCkjczhuLm0u',
        'meta_ads_token'        => 'EAAS0RMdfHpoBRJmX2CdbXS3VDEAoZCDBHKlnn5iu0E9LVqkfuQlDn5ZAafzKz8OVfI72ZC6mZB6vVMITMZBMFyWds9gRGC2qhZBTFWX1ow00NZCZBnZAZAhstPL5KoZAPFuzhABXLV8jZCNYyZCkZBsPJGEvHvHAUQGXwDI0UNZBgF4aijE0igUjDTnkNLC3uIjAgMTqswzyhNdYsCo4W2BLZAQZBJrJ7kEcrwMy2ZB5Ynlm8EU2oXHJrDAXQ8QTPzMDMbyac3iXftibNoZBNZCCUZCkjczhuLm0u',

        // ── Apify (مدوّر تلقائي بين المفاتيح المتاحة) ────────
        'apify_tokens' => [
            // ── الجديدة الأربعة (أولوية قصوى) ───────────────
            'apify_api_ElbXCaVWcHEd2BJaf7EhwlfnFQLGUN3cQjaR',
            'apify_api_6jbdAd1GEI09zG436SJAVJlDvdNGM345lC3e',
            'apify_api_VL6Vcggu0Aew8dztQZN0qivVVdra40077GNk',
            'apify_api_aGMGhhI10rvxkANTOn9GGx6HZDJwRk1usbFc',
        ],
        'apify_token'          => 'apify_api_ElbXCaVWcHEd2BJaf7EhwlfnFQLGUN3cQjaR',
        'apify_actor_fb'        => 'apify~facebook-pages-scraper',   // facebook-pages-scraper
        'apify_actor_ads_fb'    => 'apify~facebook-ads-library-scraper', // Meta Ads Library الصحيح
        'apify_actor_ads_any'   => 'JJghSZmShuco4j9gJ',   // any-platform ads scraper
        'apify_actor_ig'        => 'apify~instagram-profile-scraper', // instagram profile scraper القوي المرشح من العميل
        'apify_actor_tiktok'    => 'GdWCkxBtKWOsKjdch',   // tiktok scraper المضاف
        'apify_actor_website'   => 'apify~puppeteer-scraper', // apify/puppeteer-scraper لاستخراج HTML بعد الجافاسكربت

        // ── Groq AI (سريع جداً — Fallback) ──────────────────
        'groq_key'   => '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',
        'groq_model' => 'llama-3.3-70b-versatile',

        // ── OpenAI (Fallback) ─────────────────────────────────
        'openai_key'   => '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',
        'openai_model' => 'gpt-4o-mini',

        // ── DeepSeek Direct ───────────────────────────────────
        'deepseek_key'   => 'sk-3041f2fee6434ba3a4c725b2634d5bbd',
        'deepseek_model' => 'deepseek-chat',

        // ── Pekpik (OpenAI-Compatible — مجاني، يتجدد يومياً) ─────
        // Base URL: https://aiapiv2.pekpik.com/v1
        'pekpik_base_url' => 'https://aiapiv2.pekpik.com/v1',

        // flagship-chat = تناوب تلقائي بين GPT-5.4 + Claude + Gemini
        'pekpik_flagship_keys' => [
            'sk-tyIy3z0A8JyD1NjfL203i3i2M5XsQGAi9Z4vDHshLZyDFB0J',
            'sk-0PC0pP5C66ufac9YyQvBASPJCeFYJY7WKvb8bvtpq5BPGSIv',
            'sk-CAAMhRWG57Lrqifg22ywnBUOMcGZqOEnXWh1McrkLTM5eS9e',
            'sk-tPcRePZUtwzDcKaBUMn8JrZYyTUcRQLxMbaQAZEUcUrq6ltG',
            'sk-bNBjyUB68NiOOB0OqQX5gCLhClrFJ4YyNj79q6CEgFtrIiVT',
            'sk-0VD8NPp0KARAEi20TMpeaFOPZzOq9OhS3QgLCW5Ce7TbC6nZ',
            'sk-n5ZUciCd08JP6ct5l0k9oLDXWRGdcZ26s9oRceAhCB0cKAgG',
            'sk-5z7S13GUJncBA4gQhCDtPBqU3FA9fI5ca8ayTOPKe12vHpkY',
            'sk-pdXmFmHoJR0dsHV25tLH5g4AzSHJxBS16SFBWs1DR0hvsC2O',
            'sk-5lDn0ZyfK80dioohDptuRttv5G7lusMcKyXrf1e32NwGcAGJ',
        ],
        'pekpik_flagship_model' => 'flagship-chat',

        // gemini-2.5-pro (عالي الجودة)
        'pekpik_pro_keys' => [
            'sk-yMECqLoXj9qXXp02DWQC1aSGubbeK1p6nioifDr2HSxqq0WY',
            'sk-whBN4p2tt1i8D2BJJqMDw3BVdSNNp69uInDIKaDPaKWZNd3O',
            'sk-uQgKyUanSkeWHBBjUeGoY4G6F84mmNiRrv3h4mVgZL7o1gCv',
            'sk-e5tBzfHGeBRn0bsSVYLtjMDYPwJLfJiojs7zp9CIeemI4Ukc',
            'sk-88MNWwHn65ZFaCA0V4YDQs9ANbUREzbUB63jYAr49DxCOYQF',
            'sk-8GDKfEjvJTa5Q9XAiFgC9j0uiFot6UEy0rTHM7oAfsKAfSIN',
            'sk-bQeCETWsRGkoOVoNRcNs7J9HQqb9nSa09G5vP2MgBeYHKvTS',
            'sk-TccGrYLkeYqTsrap0smZd2SrpysZTGipSB4o861Xl3xV1jnc',
            'sk-WunqggIlaj29V19sqytrLfybcGTPskYFfjnJ75026CqKmciS',
            'sk-KCIc1hhxzgjxalsQR0nlGSS3dYd9je7CLEJWKQXigVALVc3z',
        ],
        'pekpik_pro_model' => 'gemini-2.5-pro',

        // gemini-2.5-flash (سريع)
        'pekpik_gemini_keys' => [
            'sk-yaruzK22RW69koYAuZqZPaMGyPFm2tNY3mzXV0s5W8m8FKrX',
            'sk-xGfnu2hdGqXvZ2IbDvc1F706zG5MCwZ6xDp7oUgxkoJfeK7N',
            'sk-BOsRlgw0RXFpyWtWuja5xmNseXyZaX9BzXP1XDF8kNFUlpdj',
            'sk-OzYOOiCX38oG0TGejBMFeFznDqrAY89Mb4WEj0LXGPOlDk6m',
            'sk-yyOZbdwNh785wrl5gb1WBhj7YB7dqKmdvC6qBHbxj1URKYQt',
            'sk-AtQ6cEmYuS1046EsyCfEa5asjA6LenslcW1esXvhpJpxR92k',
            'sk-09vEXbB8bkwhp8LofPul1DgyZggtmrZLcHTDltVF39DYXz1G',
            'sk-N5t01Of3jIcnAsWlMMRlhFc3DKYbUikaM74Cj5468oADUaNj',
            'sk-d8b2vguUwsqUHq93ekGZoHlD18xjGYLXR4ED90HczyEnuAiY',
            'sk-RbWFSCrMQ23C8xCWV8br1fd8L4BmmsnJL2lnLcPqXDGYfbMa',
        ],
        'pekpik_gemini_model' => 'gemini-2.5-flash',

        // deepseek-chat (30 مفتاح)
        'pekpik_keys' => [
            'sk-SuxLsZTEjwX70oe37FrpuZND2SS3q9CL9kkAJD3wO7NvqVsk',
            'sk-tT1REnOkYQnew6VIgd5zLsxXvvnz47HmfY1gyCZvr8b23ob1',
            'sk-TlPRK8w0xjZ69XF6khRNnMRfqH3vOODHP6t5d2k48zITeK4n',
            'sk-DasB79KJKPL8IlgBa7Ylaa4hZOY9xQidtrbIDlRxJZ9NtQjh',
            'sk-TzfGpFGYAmTk85yS9FSU6undLaAx0OZSwJItzwLJsLJvY3zE',
            'sk-fAHoHqB1tdGYo06imU16pMxxZnJWxgVKdy2SX84IgXuoUOze',
            'sk-K6zeUxRLxlJV2IbvyN6QJTmtBUnVM0OMJREVuvBVwWe6dUs3',
            'sk-PDIBxpulVBwgWawukaar2RQrnfLJ3e4k7n3XU9GmE17SWJeo',
            'sk-Mu9NyCn17ZcZC48SYTnfC63Ot4lW6xvL7BYviMC6D3w0OR6Z',
            'sk-6u3KoIJH7LTqizsF6lXfxzAuJI9oCOqrHB3lxlX2polttqHT',
            'sk-M0IFfNCabJgWSIbpdSyJjW8P9QyvkSOdfJI233vQVYYgC1GR',
            'sk-jHSKvBxf6yqB5iHlL5wSBy5HHT4cnZYjBmVuo6vyYTta1wL2',
            'sk-RddVfGEOVvZUHgYc1VsL6mlG1sKRjcnTcfzHuINZ4fHPOl2r',
            'sk-mtctUJKjQlDDxwD4wbCNuVdhreJtDdZBlR8pa4uEmT5taexv',
            'sk-2haGJAG5RhEfQlF9A09Phlexm5Y1gzO6t6TfYy2z7TKqvmhK',
            'sk-JSBnqfLyNNlgjzfs1FmyfZwZ0Et8oOvMK73hgmlP0yQOB4OC',
            'sk-VQZmSqr2uw0PWPsh9eFoWEyTxmVwb6ifYlVdbGGqYT2JQhXK',
            'sk-QYRISesofSey4ogVwZ33NiCH3ycXxbryUe1IQFkJDpbF266Z',
            'sk-t44dm8qI2qTCHI8SherOXzpcdQ6HeYRGQqWz5gXs8FgaMxUT',
            'sk-Nhby6WCJ0aYNnyIXZit0DUo7KO2yiQTlBsn2xc9TOOcFt6oy',
        ],
        'pekpik_model' => 'deepseek-chat',

        // ── OpenRouter (Meta Llama / Fallback) ───────────────
        'openrouter_key' => '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',

        // ── Upstash Redis (Cache & Queue) ────────────────────
        'redis_url'   => 'https://clear-guinea-89404.upstash.io',
        'redis_token' => 'gQAAAAAAAV08AAIncDJhODIwZTQ0YjU4ODk0NTEyOTIyOTY5MzljZDVmZGNjYnAyODk0MDQ',

        // ── Supabase Keys shortcuts ───────────────────────────
        'supabase_url'    => 'https://gukrhviolkjoabxtcsum.supabase.co',
        'supabase_anon'   => 'sb_publishable_OITkitMRA0CjavH1ubr1gA_ejL3gAVs',
        'supabase_secret' => 'sb_secret_k9Wq6o4JlM3CUju4y4hSnA_EH6Wbqaq',
    ],

    // ─── Rate Limiting ───────────────────────────────────────
    'rate_limit' => [
        'max_per_minute' => 10,
        'max_per_hour'   => 50,
        'max_per_day'    => 200,
    ],

    // ─── Analysis Settings ───────────────────────────────────
    'analysis' => [
        'timeout_seconds'    => 45,
        'cache_hours'        => 6,
        'enable_pagespeed'   => true,   // ✅ مفعّل
        'enable_gemini'      => true,   // ✅ مفعّل (6 مفاتيح)
        'enable_apify'       => true,   // ✅ مفعّل (6 رموز)
        'enable_instagram'   => true,   // ✅ مفعّل
        'enable_ads_library' => true,   // ✅ مفعّل (مجاني)
        'enable_groq'        => true,   // ✅ مفعّل (fallback سريع)
        'enable_cache'       => true,   // ✅ Redis cache
        // ترتيب أولوية AI: Pekpik (مجاني) → Gemini → Groq → DeepSeek
        'ai_priority' => ['nvidia', 'qwen', 'gptoss', 'pekpik', 'gemini', 'groq', 'deepseek', 'openai'],
    ],
];
