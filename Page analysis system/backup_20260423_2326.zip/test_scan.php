<?php
require 'api/page-scan.php';
$res = _fetchAndScanWebsite('https://alabeermarketing.com/', []);
print_r($res);
