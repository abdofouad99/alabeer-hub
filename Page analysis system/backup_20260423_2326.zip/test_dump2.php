<?php
require 'api/db.php';
$db = getDB();
$stmt = $db->query('SELECT id, status, scan_result, breakdown, scan_error FROM assessments ORDER BY id DESC LIMIT 1');
file_put_contents('test_dump2.json', json_encode($stmt->fetch(PDO::FETCH_ASSOC), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
echo "DONE2";
