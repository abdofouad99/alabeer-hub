<?php
// ============================================================
// api/apify-scraper.php — مكتبة دوال Apify (لا تُستدعى مباشرة)
// ============================================================
require_once __DIR__ . '/db.php';

// ← لا يوجد كود تنفيذي هنا — فقط دوال

// ============================================================
function runApifyScraper(string $url, string $type, array $cfg): array {
    // اختيار Token ذكياً (عشوائي + validation)
    $token = getValidApifyToken($cfg);
    if (!$token) return ['success' => false, 'error' => 'Apify token غير مضبوط'];

    switch ($type) {
        case 'instagram': return scrapeInstagram($url, $token, $cfg);
        case 'tiktok':    return scrapeTikTok($url, $token, $cfg);
        case 'twitter':   return scrapeTwitter($url, $token, $cfg);
        default:          return scrapeFacebook($url, $token, $cfg);
    }
}

// ============================================================
// P1-3: اختيار أفضل Token من القائمة (عشوائي + تحقق + cache)
// ============================================================
if (!function_exists('getValidApifyToken')) {
function getValidApifyToken(array $cfg): string {
    $tokens = $cfg['apis']['apify_tokens'] ?? [];
    if (empty($tokens)) return '';

    // ── Cache داخل نفس الـ PHP process (تجنب إعادة الـ validation في كل استدعاء) ──
    static $cachedToken = null;
    if ($cachedToken !== null) return $cachedToken;

    // ── الخطوة 1: اختيار عشوائي (load balancing حقيقي بدلاً من time() % count) ──
    // نسخة مُرخَّلة للقائمة لمنع نمط ثابت
    $shuffled = $tokens;
    shuffle($shuffled);

    foreach ($shuffled as $token) {
        if (empty(trim($token))) continue;

        // ── الخطوة 2: تحقق سريع (5 ثوانٍ timeout) ──
        $ch = curl_init("https://api.apify.com/v2/users/me?token={$token}");
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 5,
            CURLOPT_SSL_VERIFYPEER => false,
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($code !== 200) continue;

        $userData = json_decode($body, true);
        $isActive  = $userData['data']['isStatusActive'] ?? true;
        if (!$isActive) continue;

        // وجدنا token صالح — نُخزّنه ونُعيده
        $cachedToken = $token;
        return $token;
    }

    // Fallback: إذا فشل الـ validation لجميع التوكنات (مشكلة شبكة مؤقتة)
    // استخدم عشوائياً لتجنب التوقف الكامل
    $cachedToken = $shuffled[0];
    return $cachedToken;
}
} // end if(!function_exists('getValidApifyToken'))


// ============================================================
/**
 * scrapeAdsLibrary
 * ─────────────────────────────────────────────────────────────
 * المصدر الأساسي: بيانات pageAdLibrary التي يُرجعها Facebook Actor تلقائياً.
 * المصدر الاحتياطي: Apify actor مستقل (يُفعَّل إذا لم تتوفر بيانات Facebook).
 *
 * @param string $pageIdentifier  رابط أو اسم مستخدم أو 'ID:12345'
 * @param string $token           Apify token
 * @param array  $cfg             الإعدادات
 * @param array  $fbData          بيانات Facebook إذا سُحبت مسبقاً (اختياري)
 */
function scrapeAdsLibrary(
    string $pageIdentifier,
    string $token,
    array  $cfg      = [],
    string $country  = 'ALL',
    array  $fbData   = []
): array {

    // ── المسار الأول: استخدام pageAdLibrary من Facebook (الأسرع) ───
    $fbAdsActive = false;
    $fbAdsCount  = 0;
    if (!empty($fbData['success'])) {
        $adLib    = $fbData['pageAdLibrary'] ?? [];
        $adStatus = strtoupper($fbData['ad_status'] ?? '');

        if (!empty($adLib)) {
            $fbAdsActive = !empty($adLib['is_business_page_active']) || (($adLib['ad_count'] ?? 0) > 0);
            $fbAdsCount  = (int)($adLib['ad_count'] ?? 0);
        }
        if (!$fbAdsActive && $adStatus === 'ACTIVE') {
            $fbAdsActive = true;
        }
    }
    // لم نعد نُرجع النتيجة المبدئية هنا، بل نستخدمها كمعلومة إضافية
    // لضمان تشغيل ساحب الإعلانات المخصص (Ads Actor) وجلب صور ونصوص الإعلانات فعلياً.

    // ── المسار الاحتياطي: Apify actor منفصل ──────────────────────
    $actorId = $cfg['apis']['apify_actor_ads_fb'] ?? '';
    if (empty($actorId)) {
        return ['success' => false, 'error' => 'لا يوجد Ads Actor مُعرَّف', 'ads' => []];
    }

    // استخراج اسم الصفحة من الرابط
    $cleanQuery = $pageIdentifier;
    if (str_starts_with($pageIdentifier, 'http')) {
        preg_match('/(?:facebook|instagram)\.com\/([^\/\?#]+)/i', $pageIdentifier, $m);
        if (!empty($m[1])) $cleanQuery = trim($m[1]);
    }

    $input = [
        'searchPageOrURL' => $cleanQuery,
        'country'         => $country,
        'maxResults'      => 25,
    ];

    $fallbackReturn = [
        'success'        => true,
        'source'         => 'facebook_actor',
        'is_running_ads' => $fbAdsActive ?? false,
        'total_ads'      => $fbAdsCount ?? 0,
        'active_ads'     => ($fbAdsActive ?? false) ? ($fbAdsCount ?? 0) : 0,
        'ads_status'     => $adStatus ?? '',
        'ads'            => [],
    ];

    // ── حماية الرصيد: لا تقم بتشغيل الساحب المكلف إذا كنا متأكدين من عدم وجود إعلانات ──
    // إذا كان الساحب السريع يقول (لا توجد إعلانات نشطة) والعدد صفر، نكتفي بالنتيجة.
    if (!($fbAdsActive ?? false) && ($fbAdsCount ?? 0) === 0) {
        return $fallbackReturn;
    }

    $runId = _apifyStartRun($actorId, json_encode($input), $token);
    if (!$runId) return $fallbackReturn;

    $items = _apifyWaitAndFetch($runId, $token, 90);
    if ($items === null) return $fallbackReturn;

    $ads = [];
    foreach (($items ?: []) as $item) {
        $adsList = $item['ads'] ?? null;
        if (is_array($adsList)) {
            foreach ($adsList as $ad) $ads[] = _parseAd($ad);
        } else {
            $ads[] = _parseAd($item);
        }
    }

    if (count($ads) === 0 && ($fbAdsActive ?? false)) {
        return $fallbackReturn;
    }

    return [
        'success'        => true,
        'source'         => 'apify_actor',
        'total_ads'      => count($ads),
        'active_ads'     => count(array_filter($ads, fn($a) => $a['is_active'])),
        'ads'            => array_slice($ads, 0, 15),
        'is_running_ads' => count($ads) > 0,
    ];
}


function _parseAd(array $ad): array {
    $rawStatus = $ad['ad_delivery_status'] ?? $ad['status'] ?? '';
    $status = is_string($rawStatus) ? strtolower($rawStatus) : '';
    $images = $ad['snapshot']['images'] ?? [];
    $imgUrl = is_array($images) && isset($images[0]['original_image_url']) ? $images[0]['original_image_url'] : null;

    return [
        'id'          => $ad['adArchiveID']       ?? $ad['ad_archive_id'] ?? $ad['id']          ?? null,
        'title'       => $ad['adCreativeBody']    ?? $ad['ad_creative_body'] ?? $ad['body'] ?? $ad['title'] ?? '',
        'page_name'   => $ad['pageName']          ?? $ad['page_name'] ?? '',
        'is_active'   => ($ad['isActive'] ?? $ad['is_active'] ?? false) || $status === 'active',
        'start_date'  => $ad['startDate']         ?? $ad['start_date'] ?? $ad['ad_creation_time'] ?? null,
        'platforms'   => $ad['publisherPlatform'] ?? $ad['publisher_platforms'] ?? $ad['platforms'] ?? [],
        'spend'       => $ad['spend']             ?? null,
        'impressions' => $ad['impressions']       ?? null,
        'image_url'   => $imgUrl ?? $ad['image_url'] ?? $ad['thumbnail'] ?? null,
    ];
}


// ============================================================
// Google Search Scraper (nWGjfqxH9vqmJN76s) for Competitors
// ============================================================
function scrapeCompetitorsViaGoogle(string $companyName, string $targetAudience, string $token): array {
    $actorId = 'nWGjfqxH9vqmJN76s'; // Google Search Scraper

    // إذا لم يكن هناك اسم نشاط، لا داعي للبحث
    if (empty(trim($companyName))) return ['success' => false, 'error' => 'لا يوجد اسم نشاط للبحث عنه'];

    $location = trim($targetAudience) !== '' ? trim($targetAudience) : 'السعودية';
    $query = "أهم منافسين $companyName في $location";
    // أو صيغة أخرى
    // $query = "شركات مثل $companyName في $location";

    $input = [
        "queries" => [$query],
        "maxResults" => 10,
        "countryCode" => "SA" // Default fallback
    ];

    $runId = _apifyStartRun($actorId, json_encode($input), $token);
    if (!$runId) return ['success' => false, 'error' => 'فشل تشغيل Google Actor'];

    $result = _apifyWaitAndFetch($runId, $token, 45); // أسرع من باقي السواحب
    if (!$result) return ['success' => false, 'error' => 'انتهت مهلة Google Apify'];

    // استخراج النتائج (أول 5 نتائج Organic)
    $competitors = [];
    foreach ($result as $item) {
        $organic = $item['organicResults'] ?? [];
        foreach ($organic as $res) {
            $title = $res['title'] ?? '';
            $url = $res['url'] ?? '';
            $desc = $res['description'] ?? '';
            if (!empty($title) && !empty($url)) {
                $competitors[] = [
                    'name' => $title,
                    'url' => $url,
                    'description' => $desc
                ];
            }
        }
    }

    return [
        'success' => true,
        'competitors' => array_slice($competitors, 0, 5) // نأخذ أول 5
    ];
}

// ── Apify Internal Helpers ────────────────────────────────────
function _apifyStartRun(string $actorId, string $inputJson, string $token): ?string {
    $url = "https://api.apify.com/v2/acts/{$actorId}/runs?token={$token}";
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS     => $inputJson,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $res = json_decode($body, true);
    curl_close($ch);
    
    if ($code !== 201 && $code !== 200) {
        logError("Apify Start Run Failed", [
            "actor" => $actorId,
            "http_code" => $code,
            "response" => $res ?: $body,
            "url_mask" => "https://api.apify.com/v2/acts/{$actorId}/runs?token=***"
        ]);
        return null;
    }
    
    return $res['data']['id'] ?? null;
}

function _apifyWaitAndFetch(string $runId, string $token, int $maxWait): ?array {
    $start = time();
    while (time() - $start < $maxWait) {
        sleep(3);
        $ch = curl_init("https://api.apify.com/v2/actor-runs/{$runId}?token={$token}");
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_SSL_VERIFYPEER => false]);
        $s = json_decode(curl_exec($ch), true);
        curl_close($ch);
        $status = $s['data']['status'] ?? '';
        // Treat BOTH SUCCEEDED and FINISHED as successful completion
        if (in_array($status, ['SUCCEEDED', 'FINISHED'])) {
            $dsId = $s['data']['defaultDatasetId'] ?? '';
            if ($dsId) {
                $ch = curl_init("https://api.apify.com/v2/datasets/{$dsId}/items?token={$token}&limit=100");
                curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 12, CURLOPT_SSL_VERIFYPEER => false]);
                $items = json_decode(curl_exec($ch), true);
                curl_close($ch);
                return $items ?: [];
            }
            return [];
        }
        if (in_array($status, ['FAILED','ABORTED','TIMED-OUT'])) return null;
    }
    return null;
}

// ============================================================
// Facebook Page Scraper (apify~facebook-pages-scraper)
// نفس المنهجية التي تعمل للإنستقرام
// ============================================================
function scrapeFacebook(string $url, string $token, array $cfg): array {
    $actorId = $cfg['apis']['apify_actor_fb'] ?? 'apify~facebook-pages-scraper';

    $isPostsScraper = ($actorId === 'KoJrdxJCTtpon81KY');

    if ($isPostsScraper) {
        $input = json_encode([
            'startUrls'    => [['url' => $url]],
            'resultsLimit' => 12,
            'captionText'  => false,
        ]);
    } else {
        $input = json_encode([
            'startUrls'  => [['url' => $url]],
            'maxPosts'   => 12,
            'scrapeAbout'=> true,
        ]);
    }

    $runId = _apifyStartRun($actorId, $input, $token);
    if (!$runId) return ['success' => false, 'error' => 'فشل تشغيل Facebook Actor'];

    $result = _apifyWaitAndFetch($runId, $token, 120); // 120s because posts scraper takes longer
    if (!$result) return ['success' => false, 'error' => 'انتهت مهلة Facebook Apify'];

    // ── المعالجة بناءً على نوع الـ Actor ─────────
    if ($isPostsScraper) {
        // Actor الجديد يرجع مصفوفة من المنشورات، أول عنصر يحتوي على معلومات الصفحة
        if (empty($result)) return ['success' => false, 'error' => 'لا يوجد منشورات للتحليل (أو الصفحة مغلقة)'];
        
        $firstItem = $result[0];
        $posts = $result; // كل عنصر هو منشور
        
        $followers = $firstItem['followers'] ?? $firstItem['followersCount'] ?? $firstItem['fans'] ?? null;
        $likes     = $firstItem['likes']     ?? $firstItem['likesCount']     ?? $followers;
        $pageName  = $firstItem['title']     ?? $firstItem['pageName']       ?? $firstItem['name'] ?? '';
        $pageId    = $firstItem['facebookId'] ?? $firstItem['pageId']         ?? $firstItem['id']   ?? '';
        
        $phone = '';
        $email = '';
        $whatsapp = '';
        $website = '';
        $igUrl = '';
        $category = '';
        $is_verified = false;
        
        // جلب الإعلانات من المنشور الأول
        $adLib = $firstItem['pageAdLibrary'] ?? [];
        $adsActive = !empty($adLib['is_business_page_active']);
        $adsCount = 0;
        
        // تعيين $page ليكون $firstItem لاستخدامه في الحقول المشتركة بالأسفل
        $page = $firstItem;
        
        // محاولة استخراج المزيد من البيانات من الحقول المتاحة في الـ Actor الجديد
        $phone     = $page['phone']        ?? $page['phoneNumber']    ?? '';
        $whatsapp  = $page['whatsappNumber'] ?? '';
        $email     = $page['email']        ?? '';
        $website   = $page['website']      ?? $page['externalUrl']    ?? '';
        $category  = $page['category']     ?? '';
        $is_verified = !empty($page['isVerified']) || !empty($page['verified']);

        // ── جلب النواقص (معلومات الصفحة) عبر Actor الصفحات السريع ──
        if (empty($followers) && empty($email) && empty($phone) && empty($website)) {
            $aboutInput = json_encode([
                'startUrls' => [['url' => $url]],
                'maxPosts' => 0,
                'scrapeAbout' => true,
                'scrapeServices' => false,
                'scrapeReviews' => false
            ]);
            $aboutRunId = _apifyStartRun('apify~facebook-pages-scraper', $aboutInput, $token);
            if ($aboutRunId) {
                $aboutResult = _apifyWaitAndFetch($aboutRunId, $token, 60);
                if (!empty($aboutResult[0])) {
                    $ap = $aboutResult[0];
                    $followers = $ap['followers'] ?? $ap['followersCount'] ?? $ap['fans'] ?? $ap['likesCount'] ?? $followers;
                    $likes     = $ap['likes'] ?? $ap['likesCount'] ?? $followers;
                    $phone     = $ap['phone'] ?? $ap['phoneNumber'] ?? $phone;
                    $whatsapp  = $ap['wa_number'] ?? $ap['whatsapp_number'] ?? $ap['whatsapp'] ?? $whatsapp;
                    $email     = $ap['email'] ?? ($ap['emails'][0] ?? $email);
                    
                    $ws = $ap['website'] ?? '';
                    if (empty($ws) && !empty($ap['websites'])) {
                        $wsArray = $ap['websites'];
                        $ws = is_array($wsArray) ? ($wsArray[0] ?? '') : $wsArray;
                    }
                    $website = $ws ?: ($ap['externalUrl'] ?? $ap['websiteUrl'] ?? $website);

                    $category  = $ap['category'] ?? ($ap['categories'][0] ?? ($ap['categoryName'] ?? $category));
                    $is_verified = !empty($ap['verified']) || !empty($ap['isVerified']) || ($ap['verifiedStatus'] ?? '') === 'BLUE_VERIFIED' || $is_verified;
                    
                    // استخدام صورة الغلاف والشخصية إذا توفرت
                    $page['cover'] = $ap['cover'] ?? $page['cover'] ?? null;
                    $page['profilePic'] = $ap['profilePic'] ?? $page['profilePic'] ?? null;
                }
            }
        }
        
    } else {
        // Actor القديم يرجع كائن واحد للصفحة وداخله المنشورات
        $page = $result[0] ?? [];
        if (empty($page)) return ['success' => false, 'error' => 'لا بيانات من Facebook Actor'];

        $posts = $page['posts'] ?? $page['latestPosts'] ?? [];
        $followers = $page['followers']    ?? $page['followersCount'] ?? $page['fans'] ?? $page['likesCount'] ?? null;
        $likes     = $page['likes']        ?? $followers;
        $phone     = $page['phone']        ?? $page['phoneNumber']    ?? '';
        $whatsapp  = $page['wa_number']    ?? $page['whatsapp_number'] ?? $page['whatsapp'] ?? '';
        $email     = $page['email']        ?? $page['emails'][0]      ?? '';

        $website = $page['website'] ?? '';
        if (empty($website) && !empty($page['websites'])) {
            $ws = $page['websites'];
            $website = is_array($ws) ? ($ws[0] ?? '') : $ws;
        }
        $website = $website ?: ($page['externalUrl'] ?? $page['websiteUrl'] ?? '');
        $igUrl = $page['instagram'] ?? $page['instagramLink'] ?? '';
        $category = $page['category'] ?? $page['categories'][0] ?? $page['categoryName'] ?? '';
        $is_verified = !empty($page['verified']) || !empty($page['isVerified']) || ($page['verifiedStatus'] ?? '') === 'BLUE_VERIFIED';
        $pageName = $page['title'] ?? $page['pageName'] ?? $page['name'] ?? '';
        $pageId = $page['pageId'] ?? $page['facebookId'] ?? $page['id'] ?? '';
        
        $adLib = $page['pageAdLibrary'] ?? [];
        $adsActive = !empty($adLib['is_business_page_active']) || (($adLib['ad_count'] ?? 0) > 0);
        $adsCount = (int)($adLib['ad_count'] ?? 0);
        if (!$adsActive && !empty($page['ad_status'])) {
            $adsActive = strtoupper($page['ad_status']) === 'ACTIVE';
        }
    }

    $res = [
        'success'        => true,
        'source'         => 'apify',
        'platform'       => 'facebook',
        'page_name'      => $pageName,
        'page_id'        => $pageId,
        'url'            => $url,
        'followers'      => $followers,
        'likes'          => $likes,
        'category'       => $category,
        'is_verified'    => $is_verified,
        'website'        => $website,
        'phone'          => $phone,
        'whatsapp'       => $whatsapp,
        'email'          => $email,
        'address'        => $page['address'] ?? $page['location'] ?? $page['city'] ?? '',
        'description'    => $page['intro'] ?? $page['description'] ?? $page['about'] ?? $page['text'] ?? '',
        'rating'         => _cleanRating($page['rating'] ?? $page['overallStarRating'] ?? null),
        'ratings_count'  => $page['ratingsCount'] ?? $page['ratingCount'] ?? null,
        'posts_count'    => count($posts),
        'avg_engagement' => calcAvgEngagement($posts),
        'top_post'       => getTopPost($posts),
        'deep_analysis'  => analyzeDeepContent($posts),
        'instagram_url'  => $igUrl,
        'ads_running'    => $adsActive,
        'ads_count'      => $adsCount,
        'creation_date'  => $page['creation_date'] ?? '',
    ];

    // فقط أضف الـ signals إذا كانت حقيقية (حتى لا نمسح ما يجده الـ Scraper العام)
    if (!empty($phone))    $res['has_phone']    = true;
    if (!empty($whatsapp)) $res['has_whatsapp'] = true;
    if (!empty($email))    $res['has_email']    = true;
    if (!empty($website))  $res['has_website']  = true;
    if ($is_verified)      $res['is_verified']  = true;

    return $res;
}


// ============================================================
// Instagram Scraper (apify~instagram-profile-scraper)
// ============================================================
function scrapeInstagram(string $url, string $token, array $cfg): array {
    $actorId = $cfg['apis']['apify_actor_ig'] ?? 'apify~instagram-profile-scraper';

    // استخراج username
    preg_match('/instagram\.com\/([^\/\?#]+)/i', $url, $m);
    $username = $m[1] ?? '';
    $username = trim($username, '/@');
    $username = preg_replace('/[^a-zA-Z0-9_\.]/', '', $username);

    if (!$username) return ['success' => false, 'error' => 'لم يتم استخراج username'];

    $input = json_encode([
        'usernames' => [$username]
    ]);
    $runId = _apifyStartRun($actorId, $input, $token);

    if (!$runId) return ['success' => false, 'error' => 'فشل تشغيل Instagram Scraper'];

    $result = _apifyWaitAndFetch($runId, $token, 120);
    // إذا كانت النتيجة null يعني فشل أو مهلة، أما مصفوفة فارغة فتعني لا بيانات ولكن لا تعتبر فشلاً صراحةً
    if ($result === null) return ['success' => false, 'error' => 'انتهت مهلة Instagram Scraper'];

    $profile = $result[0] ?? [];
    if (empty($profile)) return ['success' => false, 'error' => 'لا بيانات Instagram'];

    $posts = $profile['latestPosts'] ?? $profile['posts'] ?? [];

    return [
        'success'         => true,
        'source'          => 'apify',
        'platform'        => 'instagram',
        'username'        => $profile['username']         ?? $username,
        'full_name'       => $profile['fullName']         ?? '',
        'followers'       => $profile['followersCount']   ?? null,
        'following'       => $profile['followsCount']     ?? null,
        'posts_count'     => $profile['postsCount']       ?? count($posts),
        'bio'             => $profile['biography']        ?? '',
        'bio_length'      => mb_strlen($profile['biography'] ?? ''),
        'website'         => $profile['externalUrl']      ?? '',
        'is_verified'     => $profile['verified']         ?? false,
        'is_business'     => $profile['isBusinessAccount']?? false,
        'business_category'=> $profile['businessCategoryName'] ?? '',
        'profile_pic'     => $profile['profilePicUrl']   ?? '',
        'highlights_count'=> $profile['highlightReelCount'] ?? 0,
        'has_reels'       => !empty($profile['reelsCount']) || !empty($profile['isEligibleToViewUsernameReels']),
        'avg_likes'       => calcAvgLikes($posts),
        'avg_comments'    => calcAvgComments($posts),
        'engagement_rate' => calcIGEngagement($posts, $profile['followersCount'] ?? 1),
        'top_post'        => getTopIGPost($posts),
        'deep_analysis'   => analyzeDeepContent($posts),
        'posts_per_week'  => calcPostsPerWeek($posts),
        'last_post_days'  => calcLastPostDays($posts),
    ];
}

// ============================================================
// TikTok Scraper
// ============================================================
function scrapeTikTok(string $url, string $token, array $cfg): array {
    $actorId = $cfg['apis']['apify_actor_tiktok'] ?? 'GdWCkxBtKWOsKjdch';

    // استخراج username (يدعم: @user, user, tiktok.com/@user, tiktok.com/user)
    if (!str_contains($url, 'tiktok.com')) {
        $username = ltrim($url, '@');
    } else {
        preg_match('/tiktok\.com\/@?([^\/\?#]+)/i', $url, $m);
        $username = $m[1] ?? '';
    }

    if (!$username) return ['success' => false, 'error' => 'لم يتم استخراج TikTok username'];

    logInfo("Starting TikTok scrape", ["username" => $username, "actor" => $actorId]);
    $input = json_encode([
        'profiles' => ['https://www.tiktok.com/@' . $username],
        'resultsPerPage' => 1
    ]);
    $runId = _apifyStartRun($actorId, $input, $token);
    if (!$runId) {
        logError("Failed to start TikTok run", ["actor" => $actorId]);
        return ['success' => false, 'error' => 'فشل تشغيل TikTok Scraper'];
    }

    $result = _apifyWaitAndFetch($runId, $token, 90);
    if (!$result) {
        logError("TikTok scrape timeout or failed", ["run_id" => $runId]);
        return ['success' => false, 'error' => 'انتهت مهلة TikTok Scraper'];
    }

    $profile = $result[0] ?? [];
    if (empty($profile)) {
        logError("TikTok scrape returned no data", ["run_id" => $runId, "result" => $result]);
        return ['success' => false, 'error' => 'لا بيانات TikTok'];
    }

    logInfo("TikTok scrape successful", ["username" => $username]);

    return [
        'success'    => true,
        'platform'   => 'tiktok',
        'username'   => $profile['uniqueId'] ?? $profile['authorMeta']['name'] ?? $username,
        'full_name'  => $profile['nickname'] ?? $profile['authorMeta']['nickName'] ?? '',
        'followers'  => $profile['followerCount'] ?? $profile['authorMeta']['fans'] ?? 0,
        'likes'      => $profile['heartCount'] ?? $profile['authorMeta']['heart'] ?? 0,
        'video_count'=> $profile['videoCount'] ?? $profile['authorMeta']['video'] ?? 0,
        'bio'        => $profile['signature'] ?? $profile['authorMeta']['signature'] ?? '',
        'is_verified'=> $profile['verified'] ?? $profile['authorMeta']['verified'] ?? false,
        'website'    => $profile['externalWebUrl'] ?? $profile['authorMeta']['externalUrl'] ?? '',
        'avatar'     => $profile['avatarLarger'] ?? $profile['authorMeta']['avatar'] ?? '',
    ];
}

// ============================================================
// Twitter (X) Scraper
// ============================================================
function scrapeTwitter(string $url, string $token, array $cfg): array {
    $actorId = $cfg['apis']['apify_actor_twitter'] ?? 'quacker~twitter-url-scraper';

    // استخراج username (يدعم: user, twitter.com/user, x.com/user)
    if (!str_contains($url, 'twitter.com') && !str_contains($url, 'x.com')) {
        $username = ltrim($url, '@');
    } else {
        preg_match('/(?:twitter|x)\.com\/([^\/\?#]+)/i', $url, $m);
        $username = $m[1] ?? '';
    }

    if (!$username) return ['success' => false, 'error' => 'لم يتم استخراج Twitter username'];

    logInfo("Starting Twitter scrape", ["username" => $username, "actor" => $actorId]);
    $input = json_encode([
        'startUrls' => [$url],
        'twitterHandles' => [$username],
        'maxItems' => 1,
        'getFollowers' => true,
        'getFollowing' => true,
        'getAbout' => true
    ]);
    
    $runId = _apifyStartRun($actorId, $input, $token);
    if (!$runId) {
        logError("Failed to start Twitter run", ["actor" => $actorId]);
        return ['success' => false, 'error' => 'فشل تشغيل Twitter Scraper'];
    }

    $result = _apifyWaitAndFetch($runId, $token, 90);
    if (!$result) {
        logError("Twitter scrape timeout or failed", ["run_id" => $runId]);
        return ['success' => false, 'error' => 'انتهت مهلة Twitter Scraper'];
    }

    $profile = $result[0] ?? [];
    if (empty($profile)) {
        logError("Twitter scrape returned no data", ["run_id" => $runId, "result" => $result]);
        return ['success' => false, 'error' => 'لا بيانات Twitter'];
    }

    logInfo("Twitter scrape successful", ["username" => $username]);

    return [
        'success'    => true,
        'platform'   => 'twitter',
        'username'   => $profile['screenName'] ?? $profile['userName'] ?? $username,
        'full_name'  => $profile['name'] ?? '',
        'followers'  => $profile['followersCount'] ?? 0,
        'following'  => $profile['friendsCount'] ?? $profile['followingCount'] ?? 0,
        'posts_count'=> $profile['statusesCount'] ?? $profile['tweetCount'] ?? 0,
        'bio'        => $profile['description'] ?? '',
        'location'   => $profile['location'] ?? '',
        'is_verified'=> $profile['verified'] ?? false,
        'website'    => $profile['url'] ?? $profile['external_url'] ?? '',
        'avatar'     => $profile['profileImageUrlHttps'] ?? $profile['profile_image_url_https'] ?? '',
    ];
}

// ============================================================
// Apify API Public Aliases (تعيد استخدام الدوال الداخلية _apify*)
// ============================================================
function startApifyRun(string $actorId, array $input, string $token): ?string {
    return _apifyStartRun($actorId, json_encode($input), $token);
}

function waitForApifyResult(string $runId, string $token, int $maxWait): ?array {
    return _apifyWaitAndFetch($runId, $token, $maxWait);
}

function fetchApifyDataset(string $datasetId, string $token): ?array {
    if (!$datasetId) return null;
    $url = "https://api.apify.com/v2/datasets/{$datasetId}/items?token={$token}&limit=100";
    $ch  = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_SSL_VERIFYPEER => false]);
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true) ?: null;
}

// ============================================================
// Calculation Helpers
// ============================================================
function calcAvgEngagement(array $posts): float {
    if (!$posts) return 0;
    $total = array_sum(array_map(fn($p) => (int)($p['likes'] ?? $p['likesCount'] ?? 0) + (int)($p['comments'] ?? $p['commentsCount'] ?? 0), $posts));
    return round($total / count($posts), 1);
}

function _cleanRating($val): ?float {
    if ($val === null) return null;
    if (is_numeric($val)) return round((float)$val, 1);
    // Extract first number, allowing decimals
    if (preg_match('/(\d+[\.,]\d+)/', $val, $m)) {
        return round((float)str_replace(',', '.', $m[1]), 1);
    }
    if (preg_match('/(\d+)/', $val, $m)) {
        return round((float)$m[1], 1);
    }
    return null;
}

function calcAvgLikes(array $posts): float {
    if (!$posts) return 0;
    return round(array_sum(array_column($posts, 'likesCount')) / count($posts), 1);
}

function calcAvgComments(array $posts): float {
    if (!$posts) return 0;
    return round(array_sum(array_column($posts, 'commentsCount')) / count($posts), 1);
}

function calcIGEngagement(array $posts, int $followers): float {
    if (!$posts || !$followers) return 0;
    $avg = calcAvgLikes($posts) + calcAvgComments($posts);
    return round(($avg / $followers) * 100, 2);
}

function getTopPost(array $posts): ?array {
    if (!$posts) return null;
    usort($posts, fn($a, $b) => (($b['likes'] ?? 0) + ($b['comments'] ?? 0)) - (($a['likes'] ?? 0) + ($a['comments'] ?? 0)));
    return $posts[0] ?? null;
}

function getTopIGPost(array $posts): ?array {
    if (!$posts) return null;
    usort($posts, fn($a, $b) => (($b['likesCount'] ?? 0) + ($b['commentsCount'] ?? 0)) - (($a['likesCount'] ?? 0) + ($a['commentsCount'] ?? 0)));
    return $posts[0] ?? null;
}

function calcPostsPerWeek(array $posts): float {
    if (count($posts) < 2) return 0;
    $timestamps = array_filter(array_map(fn($p) => strtotime($p['timestamp'] ?? $p['takenAt'] ?? ''), $posts));
    if (count($timestamps) < 2) return 0;
    $range = (max($timestamps) - min($timestamps));
    if ($range <= 0) return 0;
    return round(count($timestamps) / ($range / 604800), 1); // 604800 = ثواني الأسبوع
}

function calcLastPostDays(array $posts): ?int {
    if (!$posts) return null;
    $timestamps = array_filter(array_map(fn($p) => strtotime($p['timestamp'] ?? $p['takenAt'] ?? ''), $posts));
    if (!$timestamps) return null;
    return (int)((time() - max($timestamps)) / 86400);
}

// ── المحلل العميق (Deep Content Analyzer) ───────────────
function analyzeDeepContent(array $posts): array {
    if (empty($posts)) return [];
    
    $total = count($posts);
    $types = ['video' => 0, 'image' => 0, 'carousel' => 0];
    $hashtags = [];
    $totalWords = 0;
    $ctaCount = 0;
    
    // الكلمات التي لو وجدت بالنص تدل على دعوة لإجراء
    $ctaKeywords = ['رابط', 'بايو', 'bio', 'link', 'تواصل', 'واتساب', 'رسالة', 'اشتري', 'احجز', 'سجل', 'خصم', 'الآن', 'تخفيض', 'اتصل', 'موقعنا'];
    
    $parsed_posts = [];
    
    foreach ($posts as $p) {
        $text = $p['caption'] ?? $p['text'] ?? $p['message'] ?? '';
        $type = strtolower($p['type'] ?? $p['mediaType'] ?? '');
        $url = $p['url'] ?? $p['postUrl'] ?? '';
        $img = $p['displayUrl'] ?? $p['thumbnailUrl'] ?? $p['imageUrl'] ?? $p['image'] ?? '';
        $likes = (int)($p['likesCount'] ?? $p['likes'] ?? 0);
        $comments = (int)($p['commentsCount'] ?? $p['comments'] ?? 0);
        
        // 1. فرز الأنواع
        if (str_contains($type, 'video') || str_contains($type, 'reel')) {
            $types['video']++;
        } elseif (str_contains($type, 'sidecar') || str_contains($type, 'album') || str_contains($type, 'carousel')) {
            $types['carousel']++;
        } else {
            $types['image']++;
        }
        
        // 2. كيمياء النصوص
        $wordArray = preg_split('/\s+/', trim($text));
        $wordsCount = empty(trim($text)) ? 0 : count($wordArray);
        $totalWords += $wordsCount;
        
        // 3. بناء سحابة الهاشتاج
        preg_match_all('/#([\p{L}\p{N}_]+)/u', $text, $matches);
        foreach ($matches[1] as $ht) {
            $ht = mb_strtolower($ht);
            $hashtags[$ht] = ($hashtags[$ht] ?? 0) + 1;
        }
        if (isset($p['hashtags']) && is_array($p['hashtags'])) {
            foreach ($p['hashtags'] as $ht) {
                if (is_string($ht)) {
                    $ht = mb_strtolower(ltrim($ht, '#'));
                    $hashtags[$ht] = ($hashtags[$ht] ?? 0) + 1;
                }
            }
        }
        
        // 4. فحص الـ CTA
        $hasCta = false;
        foreach ($ctaKeywords as $cta) {
            if (mb_stripos($text, $cta) !== false) {
                $hasCta = true; break;
            }
        }
        if ($hasCta) $ctaCount++;
        
        // 5. تجميع بيانات المنشورات للأفضل
        $parsed_posts[] = [
            'url' => $url,
            'image' => $img,
            'text' => mb_strlen($text) > 80 ? mb_substr($text, 0, 80) . '...' : (empty($text) ? 'بدون نص' : $text),
            'engagement' => $likes + $comments,
            'likes' => $likes,
            'comments' => $comments,
        ];
    }
    
    // استخراج أفضل 5 منشورات
    usort($parsed_posts, fn($a, $b) => $b['engagement'] - $a['engagement']);
    $top5 = array_slice($parsed_posts, 0, 5);
    
    // ترتيب الهاشتاجات بأكثرها تكراراً
    arsort($hashtags);
    $topHashtags = array_slice(array_keys($hashtags), 0, 10);
    
    return [
        'posts_analyzed' => $total,
        'types_percent' => [
            'video' => round(($types['video'] / $total) * 100),
            'image' => round(($types['image'] / $total) * 100),
            'carousel' => round(($types['carousel'] / $total) * 100),
        ],
        'avg_words' => round($totalWords / $total),
        'top_hashtags' => $topHashtags,
        'cta_percent' => round(($ctaCount / $total) * 100),
        'top_5_posts' => $top5
    ];
}

// ============================================================
// Website Headless Scraper (Apify Puppeteer) - حل جذري لعمق الفحص
// ============================================================
function scrapeWebsiteApify(string $url, string $token, array $cfg): ?string {
    $actorId = $cfg['apis']['apify_actor_website'] ?? 'apify/puppeteer-scraper';

    // نستخدم puppeteer-scraper لاستخراج الكود بعد الجافاسكربت
    // الانتظار 3.5 ثوانٍ يضمن لـ Google Tag manager والبيكسلات أن تحقن نفسها
    $pageFunction = "async function pageFunction(context) { 
        await new Promise(r => setTimeout(r, 3500));
        return { 
            html: await context.page.content()
        }; 
    }";

    $input = json_encode([
        'startUrls' => [['url' => $url]],
        'pageFunction' => $pageFunction,
        'proxyConfiguration' => ['useApifyProxy' => true]
    ]);

    // يبدأ السكربنج
    $runId = _apifyStartRun($actorId, $input, $token);
    if (!$runId) return null;

    // أقصى انتظار 45 ثانية لأن المواقع قد تختلف في الاستجابة
    $result = _apifyWaitAndFetch($runId, $token, 45); 
    
    return $result[0]['html'] ?? null;
}
