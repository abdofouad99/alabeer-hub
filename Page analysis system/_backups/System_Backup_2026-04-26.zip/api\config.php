<?php
// ============================================================
// api/config.php — إعدادات النظام الكاملة v3.0
// ============================================================

// ─── Helper: اختيار Gemini Key تلقائياً بالتناوب ────────────
if (!function_exists('getGeminiKey')) {
    function getGeminiKey(array $cfg): string {
        $keys = $cfg['apis']['gemini_keys'] ?? [];
        if (empty($keys)) return '';
        return $keys[time() % count($keys)];
    }
}

// ─── Helper: اختيار Apify Token تلقائياً بالتناوب ───────────
if (!function_exists('getApifyToken')) {
    function getApifyToken(array $cfg): string {
        $tokens = $cfg['apis']['apify_tokens'] ?? [];
        if (empty($tokens)) return '';
        return $tokens[time() % count($tokens)];
    }
}

// ─── تحميل .env ────────────────────────────────────────────
$envPath = __DIR__ . '/../.env';
$env = file_exists($envPath) ? parse_ini_file($envPath) : [];

$getEnv = function(string $key, $default = '') use ($env) {
    return $env[$key] ?? $_ENV[$key] ?? getenv($key) ?: $default;
};

return [

    // ─── قاعدة البيانات (Local by Flywheel) ─────────────────
    'db' => [
        'host'    => $getEnv('DB_HOST', '127.0.0.1:10006'),
        'name'    => $getEnv('DB_NAME', 'local'),
        'user'    => $getEnv('DB_USER', 'root'),
        'pass'    => $getEnv('DB_PASS', 'root'),
        'charset' => $getEnv('DB_CHARSET', 'utf8mb4'),
    ],

    // ─── Supabase (للمزامنة والنسخ الاحتياطي) ───────────────
    'supabase' => [
        'url'        => $getEnv('SUPABASE_URL', 'https://gukrhviolkjoabxtcsum.supabase.co'),
        'anon_key'   => $getEnv('SUPABASE_ANON_KEY', ''),
        'secret_key' => $getEnv('SUPABASE_SECRET_KEY', ''),
        'db_url'     => $getEnv('SUPABASE_DB_URL', ''),
    ],

    // ─── Admin ───────────────────────────────────────────────
    'admin' => [
        'session_name'     => 'alabeer_admin_sess',
        'session_lifetime' => 7200,
    ],

    // ─── App Settings ────────────────────────────────────────
    'app' => [
        'wa_number' => '967739537053',
        'version'   => '3.0',
        'name'      => 'بصمة النمو — تحليل الصفحات',
    ],

    // ─── API Keys ────────────────────────────────────────────
    'apis' => [

        // ── Gemini AI (مدوّر تلقائي بين 6 مفاتيح) ───────────
        'gemini_keys' => array_values(array_filter([
            $getEnv('GEMINI_KEY_1'),
            $getEnv('GEMINI_KEY_2'),
            $getEnv('GEMINI_KEY_3'),
            $getEnv('GEMINI_KEY_4'),
            $getEnv('GEMINI_KEY_5'),
            $getEnv('GEMINI_KEY_6'),
        ])),
        // المفتاح الأساسي (يُختار تلقائياً من القائمة)
        'gemini_key'   => $getEnv('GEMINI_KEY_1', ''),
        'gemini_model' => $getEnv('GEMINI_MODEL', 'gemini-2.0-flash'),

        // ── Google PageSpeed (يعمل بدون مفتاح بحد محدود) ────
        'google_pagespeed_key' => 'AIzaSyBr0_DfElo2jOq6B3SghhfQ4Y6BnRQa3Jk', // تم إضافة المفتاح بنجاح

        // ── Facebook Graph API ───────────────────────────────
        'facebook_access_token' => $getEnv('FACEBOOK_ACCESS_TOKEN', ''),
        'meta_ads_token'        => $getEnv('META_ADS_TOKEN', ''),

        // ── Apify (مدوّر تلقائي بين المفاتيح المتاحة) ────────
        'apify_tokens' => array_values(array_filter([
            $getEnv('APIFY_TOKEN'),
        ])),
        'apify_token'          => $getEnv('APIFY_TOKEN', ''),
        'apify_actor_fb'        => 'KoJrdxJCTtpon81KY',   // Facebook Posts Scraper (يدعم المنشورات والتفاعل)
        'apify_actor_ads_fb'    => 'apify~facebook-ads-library-scraper', // Meta Ads Library الصحيح
        'apify_actor_ads_any'   => 'JJghSZmShuco4j9gJ',   // any-platform ads scraper
        'apify_actor_ig'        => 'apify~instagram-profile-scraper', // instagram profile scraper القوي المرشح من العميل
        'apify_actor_tiktok'    => 'GdWCkxBtKWOsKjdch',
        'apify_actor_twitter'   => 'V38PZzpEgOfeeWvZY',
        'apify_actor_website'   => 'apify~puppeteer-scraper', // apify/puppeteer-scraper لاستخراج HTML بعد الجافاسكربت

        // ── Groq AI (سريع جداً — Fallback) ──────────────────
        'groq_key'   => $getEnv('GROQ_KEY', ''),
        'groq_model' => $getEnv('GROQ_MODEL', 'llama-3.3-70b-versatile'),

        // ── OpenAI (Fallback) ─────────────────────────────────
        'openai_key'   => $getEnv('OPENAI_KEY', ''),
        'openai_model' => $getEnv('OPENAI_MODEL', 'gpt-4o-mini'),

        // ── DeepSeek Direct ───────────────────────────────────
        'deepseek_key'   => $getEnv('DEEPSEEK_KEY', ''),
        'deepseek_model' => $getEnv('DEEPSEEK_MODEL', 'deepseek-chat'),

        // ── Pekpik (OpenAI-Compatible — مجاني، يتجدد يومياً) ─────
        // Base URL: https://aiapiv2.pekpik.com/v1
        'pekpik_base_url' => 'https://aiapiv2.pekpik.com/v1',

        // flagship-chat = تناوب تلقائي بين GPT-5.4 + Claude + Gemini
        'pekpik_flagship_keys' => [
            'sk-tyIy3z0A8JyD1NjfL203i3i2M5XsQGAi9Z4vDHshLZyDFB0J',
            'sk-0PC0pP5C66ufac9YyQvBASPJCeFYJY7WKvb8bvtpq5BPGSIv',
            'sk-CAAMhRWG57Lrqifg22ywnBUOMcGZqOEnXWh1McrkLTM5eS9e',
            'sk-tPcRePZUtwzDcKaBUMn8JrZYyTUcRQLxMbaQAZEUcUrq6ltG',
            'sk-bNBjyUB68NiOOB0OqQX5gCLhClrFJ4YyNj79q6CEgFtrIiVT',
            'sk-0VD8NPp0KARAEi20TMpeaFOPZzOq9OhS3QgLCW5Ce7TbC6nZ',
            'sk-n5ZUciCd08JP6ct5l0k9oLDXWRGdcZ26s9oRceAhCB0cKAgG',
            'sk-5z7S13GUJncBA4gQhCDtPBqU3FA9fI5ca8ayTOPKe12vHpkY',
            'sk-pdXmFmHoJR0dsHV25tLH5g4AzSHJxBS16SFBWs1DR0hvsC2O',
            'sk-5lDn0ZyfK80dioohDptuRttv5G7lusMcKyXrf1e32NwGcAGJ',
        ],
        'pekpik_flagship_model' => 'flagship-chat',

        // gemini-2.5-pro (عالي الجودة)
        'pekpik_pro_keys' => [
            'sk-yMECqLoXj9qXXp02DWQC1aSGubbeK1p6nioifDr2HSxqq0WY',
            'sk-whBN4p2tt1i8D2BJJqMDw3BVdSNNp69uInDIKaDPaKWZNd3O',
            'sk-uQgKyUanSkeWHBBjUeGoY4G6F84mmNiRrv3h4mVgZL7o1gCv',
            'sk-e5tBzfHGeBRn0bsSVYLtjMDYPwJLfJiojs7zp9CIeemI4Ukc',
            'sk-88MNWwHn65ZFaCA0V4YDQs9ANbUREzbUB63jYAr49DxCOYQF',
            'sk-8GDKfEjvJTa5Q9XAiFgC9j0uiFot6UEy0rTHM7oAfsKAfSIN',
            'sk-bQeCETWsRGkoOVoNRcNs7J9HQqb9nSa09G5vP2MgBeYHKvTS',
            'sk-TccGrYLkeYqTsrap0smZd2SrpysZTGipSB4o861Xl3xV1jnc',
            'sk-WunqggIlaj29V19sqytrLfybcGTPskYFfjnJ75026CqKmciS',
            'sk-KCIc1hhxzgjxalsQR0nlGSS3dYd9je7CLEJWKQXigVALVc3z',
        ],
        'pekpik_pro_model' => 'gemini-2.5-pro',

        // gemini-2.5-flash (سريع)
        'pekpik_gemini_keys' => [
            'sk-yaruzK22RW69koYAuZqZPaMGyPFm2tNY3mzXV0s5W8m8FKrX',
            'sk-xGfnu2hdGqXvZ2IbDvc1F706zG5MCwZ6xDp7oUgxkoJfeK7N',
            'sk-BOsRlgw0RXFpyWtWuja5xmNseXyZaX9BzXP1XDF8kNFUlpdj',
            'sk-OzYOOiCX38oG0TGejBMFeFznDqrAY89Mb4WEj0LXGPOlDk6m',
            'sk-yyOZbdwNh785wrl5gb1WBhj7YB7dqKmdvC6qBHbxj1URKYQt',
            'sk-AtQ6cEmYuS1046EsyCfEa5asjA6LenslcW1esXvhpJpxR92k',
            'sk-09vEXbB8bkwhp8LofPul1DgyZggtmrZLcHTDltVF39DYXz1G',
            'sk-N5t01Of3jIcnAsWlMMRlhFc3DKYbUikaM74Cj5468oADUaNj',
            'sk-d8b2vguUwsqUHq93ekGZoHlD18xjGYLXR4ED90HczyEnuAiY',
            'sk-RbWFSCrMQ23C8xCWV8br1fd8L4BmmsnJL2lnLcPqXDGYfbMa',
        ],
        'pekpik_gemini_model' => 'gemini-2.5-flash',

        // deepseek-chat (30 مفتاح)
        'pekpik_keys' => [
            'sk-SuxLsZTEjwX70oe37FrpuZND2SS3q9CL9kkAJD3wO7NvqVsk',
            'sk-tT1REnOkYQnew6VIgd5zLsxXvvnz47HmfY1gyCZvr8b23ob1',
            'sk-TlPRK8w0xjZ69XF6khRNnMRfqH3vOODHP6t5d2k48zITeK4n',
            'sk-DasB79KJKPL8IlgBa7Ylaa4hZOY9xQidtrbIDlRxJZ9NtQjh',
            'sk-TzfGpFGYAmTk85yS9FSU6undLaAx0OZSwJItzwLJsLJvY3zE',
            'sk-fAHoHqB1tdGYo06imU16pMxxZnJWxgVKdy2SX84IgXuoUOze',
            'sk-K6zeUxRLxlJV2IbvyN6QJTmtBUnVM0OMJREVuvBVwWe6dUs3',
            'sk-PDIBxpulVBwgWawukaar2RQrnfLJ3e4k7n3XU9GmE17SWJeo',
            'sk-Mu9NyCn17ZcZC48SYTnfC63Ot4lW6xvL7BYviMC6D3w0OR6Z',
            'sk-6u3KoIJH7LTqizsF6lXfxzAuJI9oCOqrHB3lxlX2polttqHT',
            'sk-M0IFfNCabJgWSIbpdSyJjW8P9QyvkSOdfJI233vQVYYgC1GR',
            'sk-jHSKvBxf6yqB5iHlL5wSBy5HHT4cnZYjBmVuo6vyYTta1wL2',
            'sk-RddVfGEOVvZUHgYc1VsL6mlG1sKRjcnTcfzHuINZ4fHPOl2r',
            'sk-mtctUJKjQlDDxwD4wbCNuVdhreJtDdZBlR8pa4uEmT5taexv',
            'sk-2haGJAG5RhEfQlF9A09Phlexm5Y1gzO6t6TfYy2z7TKqvmhK',
            'sk-JSBnqfLyNNlgjzfs1FmyfZwZ0Et8oOvMK73hgmlP0yQOB4OC',
            'sk-VQZmSqr2uw0PWPsh9eFoWEyTxmVwb6ifYlVdbGGqYT2JQhXK',
            'sk-QYRISesofSey4ogVwZ33NiCH3ycXxbryUe1IQFkJDpbF266Z',
            'sk-t44dm8qI2qTCHI8SherOXzpcdQ6HeYRGQqWz5gXs8FgaMxUT',
            'sk-Nhby6WCJ0aYNnyIXZit0DUo7KO2yiQTlBsn2xc9TOOcFt6oy',
        ],
        'pekpik_model' => 'deepseek-chat',

        // ── OpenRouter (Meta Llama / Fallback) ───────────────
        'openrouter_key' => $getEnv('OPENROUTER_KEY', ''),

        // ── Upstash Redis (Cache & Queue) ────────────────────
        'redis_url'   => $getEnv('REDIS_URL', ''),
        'redis_token' => $getEnv('REDIS_TOKEN', ''),

        // ── Supabase Keys shortcuts ───────────────────────────
        'supabase_url'    => $getEnv('SUPABASE_URL', ''),
        'supabase_anon'   => $getEnv('SUPABASE_ANON_KEY', ''),
        'supabase_secret' => $getEnv('SUPABASE_SECRET_KEY', ''),
    ],

    // ─── Rate Limiting ───────────────────────────────────────
    'rate_limit' => [
        'max_per_minute' => 10,
        'max_per_hour'   => 50,
        'max_per_day'    => 200,
    ],

    // ─── Logging ─────────────────────────────────────────────
    'logging' => [
        'enabled'       => true,
        'level'         => 'INFO', // DEBUG, INFO, WARNING, ERROR
        'file_path'     => __DIR__ . '/../logs/app.log',
        'max_file_size' => 10 * 1024 * 1024, // 10MB
        'max_files'     => 5,
    ],

    // ─── Caching ─────────────────────────────────────────────
    'cache' => [
        'enabled'       => true,
        'driver'        => 'file', // redis, file, apcu
        'ttl'           => 3600, // 1 hour default
        'redis' => [
            'url'   => $getEnv('REDIS_URL', ''),
            'token' => $getEnv('REDIS_TOKEN', ''),
        ],
        'file' => [
            'path' => __DIR__ . '/../cache/',
        ],
    ],

    // ─── Analysis Settings ───────────────────────────────────
    'analysis' => [
        'timeout_seconds'    => 45,
        'cache_hours'        => 6,
        'enable_pagespeed'   => true,   // ✅ مفعّل
        'enable_gemini'      => true,   // ✅ مفعّل (6 مفاتيح)
        'enable_apify'       => true,   // ✅ مفعّل (6 رموز)
        'enable_instagram'   => true,   // ✅ مفعّل
        'enable_tiktok'      => true,   // ✅ مفعّل
        'enable_twitter'     => true,   // ✅ مفعّل
        'enable_ads_library' => true,   // ✅ مفعّل (مجاني)
        'enable_groq'        => true,   // ✅ مفعّل (fallback سريع)
        'enable_cache'       => true,   // ✅ Redis cache
        // ── ترتيب أولوية AI (سريع أولاً → قوي كـ Fallback) ──
        // المرحلة 1: سريع وموثوق (يُجيب في ثوانٍ — 90% من الحالات)
        // المرحلة 2: قوي ومتقدم (Fallback عند الفشل)
        // المرحلة 3: عمالقة احتياطية (نادراً ما نصل إليها)
        'ai_priority' => [
            'pekpik',        // 🥇 Pekpik — GPT+Claude+Gemini تناوب (سريع + 40 مفتاح)
            'gemini',        // 🥈 Gemini Flash — سريع جداً (6 مفاتيح)
            'groq',          // 🥉 Groq Llama 70B — أسرع API في العالم (Fallback فوري)
            'nvidia',        // 4️⃣  Llama 4 Maverick 17B — NVIDIA سريع
            'qwen',          // 5️⃣  Qwen3.5 122B — جيد ومتوازن
            'gptoss',        // 6️⃣  GPT-OSS 120B — قوي
            'deepseek',      // 7️⃣  DeepSeek Direct — احتياط
            'openai',        // 8️⃣  OpenAI GPT-4o-mini — احتياط
            'deepseek_r1',   // 9️⃣  DeepSeek R1 671B (بطيء جداً — آخر فرصة)
            'qwen3_235b',    // 🔟  Qwen3 235B (بطيء — آخر فرصة)
            'llama_405b',    // 1️⃣1️⃣ Llama 3.1 405B (بطيء — آخر فرصة)
            'nemotron',      // 1️⃣2️⃣ Nemotron 253B (أبطأ — احتياط أخير)
        ],
    ],
];
