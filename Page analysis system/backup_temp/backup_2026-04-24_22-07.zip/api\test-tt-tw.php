<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/apify-scraper.php';

$cfg = require __DIR__ . '/config.php';

echo "Testing TikTok Scraper...\n";
$tiktokResult = scanTikTokPublic("https://www.tiktok.com/@aljazeera", $cfg);
print_r($tiktokResult);

echo "\nTesting Twitter Scraper...\n";
$twitterResult = scanTwitterPublic("https://twitter.com/aljazeera", $cfg);
print_r($twitterResult);
