<?php
header('Content-Type: text/html; charset=utf-8');
set_time_limit(120);
ini_set('display_errors', 1);
error_reporting(E_ALL);

$testUrl = isset($_GET['url']) ? $_GET['url'] : 'https://alabeermarketing.com';

require_once __DIR__ . '/db.php';
$cfg = require __DIR__ . '/config.php';

$lines = array();
function addLine($label, $ok, $detail = '') {
    global $lines;
    $lines[] = array('label' => $label, 'ok' => $ok, 'detail' => $detail);
}

// ── 1. DB ─────────────────────────────────────────────────────
try {
    $db    = getDB();
    $count = $db->query("SELECT COUNT(*) FROM assessments")->fetchColumn();
    addLine("قاعدة البيانات", true, "متصل - عدد التقييمات: " . $count);
} catch (Exception $e) {
    addLine("قاعدة البيانات", false, $e->getMessage());
    $db = null;
}

// ── 2. Page Scan ──────────────────────────────────────────────
try {
    require_once __DIR__ . '/page-scan.php';
    $t0   = microtime(true);
    $scan = runPageScan($testUrl, $cfg);
    $dur  = round(microtime(true) - $t0, 2);

    $ws          = $scan['website_scan'] ?? array();
    $urlSSL      = str_starts_with(strtolower($testUrl), 'https://');
    $hasPixel    = $ws['has_fb_pixel'] ?? $scan['has_fb_pixel']  ?? false;
    $hasGA       = $ws['has_ga']       ?? $scan['has_ga']        ?? false;
    $hasSSL      = $ws['has_ssl']      ?? $urlSSL;
    $hasWhatsApp = $ws['has_whatsapp'] ?? $scan['has_whatsapp']  ?? false;

    $signals  = ($hasPixel    ? '[OK]' : '[NO]') . ' Pixel  ';
    $signals .= ($hasGA       ? '[OK]' : '[NO]') . ' GA  ';
    $signals .= ($hasSSL      ? '[OK]' : '[NO]') . ' SSL  ';
    $signals .= ($hasWhatsApp ? '[OK]' : '[NO]') . ' WhatsApp';
    $wsStatus = empty($ws) ? '[website_scan=EMPTY - السيرفر لا يصل للموقع]' : '[website_scan=OK]';

    addLine("Page Scanner ({$dur}s) {$wsStatus}", !empty($scan), $signals);
} catch (Exception $e) {
    addLine("Page Scanner", false, $e->getMessage());
}

// ── 3. Gemini AI via CURL ─────────────────────────────────────
try {
    $key = getGeminiKey($cfg);
    if (empty($key)) {
        addLine("Gemini AI", false, "لا يوجد مفتاح");
    } else {
        $apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={$key}";
        $body   = '{"contents":[{"parts":[{"text":"say OK"}]}]}';
        $ch = curl_init($apiUrl);
        curl_setopt_array($ch, array(
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 12,
            CURLOPT_HTTPHEADER     => array('Content-Type: application/json'),
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_SSL_VERIFYPEER => false,
        ));
        $resp     = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        if ($resp && $httpCode === 200) {
            $j    = json_decode($resp, true);
            $text = isset($j['candidates'][0]['content']['parts'][0]['text'])
                  ? $j['candidates'][0]['content']['parts'][0]['text'] : 'no text';
            addLine("Gemini AI (curl)", true, "يعمل! الرد: " . trim($text));
        } else {
            addLine("Gemini AI (curl)", false, "HTTP: {$httpCode} | cURL: {$curlErr}");
        }
    }
} catch (Exception $e) {
    addLine("Gemini AI", false, $e->getMessage());
}

// ── 4. Full Analysis ──────────────────────────────────────────
if ($db) {
    try {
        $db->prepare("INSERT INTO leads (full_name, phone, website_url, source) VALUES (?,?,?,?)")
           ->execute(array('Test System', '0500000000', $testUrl, 'system_test'));
        $leadId = (int)$db->lastInsertId();

        $db->prepare("INSERT INTO assessments (lead_id, status) VALUES (?,?)")
           ->execute(array($leadId, 'submitted'));
        $assessId = (int)$db->lastInsertId();

        addLine("إنشاء سجل", true, "lead={$leadId} assessment={$assessId}");

        require_once __DIR__ . '/analyze.php';
        $t0     = microtime(true);
        $result = runAnalysis($assessId);
        $dur    = round(microtime(true) - $t0, 2);

        if (!empty($result['ok'])) {
            $score = $result['score'];
            $tier  = $result['tier'];
            addLine("التحليل الكامل ({$dur}s)", true, "الدرجة: {$score}/100  التصنيف: {$tier}");
            addLine("Report Link", true, "result.html?id={$assessId}");
        } else {
            addLine("التحليل الكامل", false, isset($result['error']) ? $result['error'] : 'خطأ غير معروف');
            $db->prepare("DELETE FROM assessments WHERE id=?")->execute(array($assessId));
            $db->prepare("DELETE FROM leads WHERE id=?")->execute(array($leadId));
        }
    } catch (Exception $e) {
        addLine("التحليل الكامل", false, $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html dir="rtl">
<head>
<meta charset="UTF-8">
<title>اختبار النظام</title>
<style>
  body { font-family: Cairo,Arial,sans-serif; background:#0a0a0a; color:#fff; padding:30px; max-width:900px; margin:auto; }
  h1   { color:#f58e1a; }
  .row { margin:10px 0; padding:14px 18px; border-radius:10px; background:#111; border-right:4px solid #333; }
  .ok  { border-color:#10b981; }
  .err { border-color:#ef4444; }
  .label  { font-size:16px; font-weight:bold; }
  .detail { font-size:13px; color:#94a3b8; margin-top:6px; font-family:monospace; }
  a { color:#f58e1a; font-size:18px; font-weight:bold; }
</style>
</head>
<body>
<h1>🔬 اختبار شامل للنظام</h1>
<p style="color:#666">الرابط: <?php echo htmlspecialchars($testUrl); ?></p>

<?php foreach ($lines as $line): ?>
<div class="row <?php echo $line['ok'] ? 'ok' : 'err'; ?>">
  <div class="label"><?php echo $line['ok'] ? '✅' : '❌'; ?> <?php echo htmlspecialchars($line['label']); ?></div>
  <?php if ($line['detail']): ?>
  <div class="detail"><?php echo htmlspecialchars($line['detail']); ?></div>
  <?php endif; ?>
</div>
<?php endforeach; ?>
</body>
</html>
