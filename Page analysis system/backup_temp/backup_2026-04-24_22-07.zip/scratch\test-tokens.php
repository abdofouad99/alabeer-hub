<?php
require_once __DIR__ . '/../api/config.php';
$cfg = require __DIR__ . '/../api/config.php';
$tokens = $cfg['apis']['apify_tokens'] ?? [];

echo "--- Apify Token Verification ---\n";

foreach ($tokens as $token) {
    echo "\nTesting Token: " . substr($token, 0, 15) . "...\n";
    
    // Check user info and status
    $ch = curl_init("https://api.apify.com/v2/users/me?token={$token}");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($code === 200) {
        $data = json_decode($body, true);
        $username = $data['data']['username'] ?? 'Unknown';
        echo "[SUCCESS] Token is valid. User: $username\n";
        
        // Try a tiny request to check for limits
        // We'll try to list runs for a generic actor (doesn't start a run, just checks API access)
        $ch2 = curl_init("https://api.apify.com/v2/acts/apify~facebook-pages-scraper/runs?token={$token}&limit=1");
        curl_setopt_array($ch2, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_SSL_VERIFYPEER => false,
        ]);
        $body2 = curl_exec($ch2);
        $code2 = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
        curl_close($ch2);
        
        if ($code2 === 403) {
            $err = json_decode($body2, true);
            $msg = $err['error']['message'] ?? 'Unknown 403 error';
            echo "[ERROR] Access Denied: $msg\n";
        } elseif ($code2 === 200) {
            echo "[SUCCESS] API Access is functional (Limits OK).\n";
        } else {
            echo "[WARNING] Unexpected status code: $code2\n";
            echo "Body: $body2\n";
        }
    } else {
        echo "[FAILED] Invalid Token or API error. Code: $code\n";
        echo "Response: $body\n";
    }
}
