<?php
// ============================================================
// api/test-log.php — اختبار نظام التسجيل
// ============================================================

require_once __DIR__ . '/init.php';

header('Content-Type: application/json; charset=utf-8');

try {
    logInfo('Testing logging system');

    // اختبار مستويات مختلفة
    logDebug('Debug message', ['test' => true]);
    logInfo('Info message', ['user' => 'test_user']);
    logWarning('Warning message', ['issue' => 'test_issue']);
    logError('Error message', ['error' => 'test_error']);

    // اختبار مع context
    logInfo('Test completed', [
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
        'timestamp' => date('Y-m-d H:i:s')
    ]);

    echo json_encode(['logging_test' => 'success', 'message' => 'Check logs/app.log for test entries']);

} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>