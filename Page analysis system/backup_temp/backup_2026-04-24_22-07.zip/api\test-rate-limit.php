<?php
// ============================================================
// api/test-rate-limit.php — اختبار نظام تقييد المعدل
// ============================================================

require_once __DIR__ . '/init.php';

header('Content-Type: application/json; charset=utf-8');

try {
    logInfo('Testing rate limiting system');

    // اختبار التحقق من rate limit
    $allowed = checkApiRateLimit('test_action');
    echo json_encode(['rate_limit_check' => $allowed ? 'allowed' : 'blocked']);

    // الحصول على headers
    $headers = getRateLimitHeaders($db, $config, $logger, 'test_action');
    foreach ($headers as $h => $v) {
        header("$h: $v");
    }

    // إحصائيات
    $stats = getRateLimiter($db, $config, $logger)->getStats();
    echo json_encode(['stats' => $stats]);

    logInfo('Rate limit test completed', ['allowed' => $allowed]);

} catch (Exception $e) {
    logError('Rate limit test failed', ['error' => $e->getMessage()]);
    echo json_encode(['error' => $e->getMessage()]);
}
?>