<?php
// ============================================================
// api/test-cache.php — اختبار نظام التخزين المؤقت
// ============================================================

require_once __DIR__ . '/init.php';

header('Content-Type: application/json; charset=utf-8');

try {
    logInfo('Testing cache system');

    // اختبار تخزين بسيط
    $testKey = 'test_' . time();
    $testData = ['message' => 'Hello Cache!', 'timestamp' => time()];

    // تخزين
    $stored = cacheSet($testKey, $testData, 300);
    echo json_encode(['cache_set' => $stored ? 'success' : 'failed']);

    // استرجاع
    $retrieved = cacheGet($testKey);
    echo json_encode(['cache_get' => $retrieved ? 'success' : 'failed', 'data' => $retrieved]);

    // اختبار cacheRemember
    $remembered = cacheRemember('remember_test', function() {
        return ['computed' => true, 'value' => rand(1, 100)];
    }, 60);

    echo json_encode(['cache_remember' => 'success', 'data' => $remembered]);

    logInfo('Cache test completed successfully');

} catch (Exception $e) {
    logError('Cache test failed', ['error' => $e->getMessage()]);
    echo json_encode(['error' => $e->getMessage()]);
}
?>