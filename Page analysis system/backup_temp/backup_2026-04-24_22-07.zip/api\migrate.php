<?php
// ============================================================
// api/migrate.php — تشغيل الـ migrations
// ============================================================

require_once __DIR__ . '/init.php';

try {
    logInfo('Starting database migration');

    // إضافة جدول rate_limits
    $db->exec("
        CREATE TABLE IF NOT EXISTS `rate_limits` (
          `id`            INT UNSIGNED     NOT NULL AUTO_INCREMENT,
          `created_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
          `ip`            VARCHAR(45)      NOT NULL,
          `action`        VARCHAR(100)     NOT NULL DEFAULT 'api_request',
          `user_agent`    TEXT,
          PRIMARY KEY (`id`),
          KEY `idx_ip_action` (`ip`, `action`),
          KEY `idx_created_at` (`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    logInfo('Migration completed successfully');
    echo "Migration completed successfully!\n";

} catch (Exception $e) {
    logError('Migration failed', ['error' => $e->getMessage()]);
    echo "Migration failed: " . $e->getMessage() . "\n";
}
?>