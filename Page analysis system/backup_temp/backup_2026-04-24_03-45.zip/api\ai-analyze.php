<?php
// ============================================================
// api/ai-analyze.php — تحليل ذكي بـ Gemini AI
// POST /api/ai-analyze.php
// Body: { "assessment_id": 123 } OR { "data": {...} }
// ============================================================
require_once __DIR__ . '/db.php';

// ── تشغيل مباشر فقط (ليس عند require من ملف آخر) ───────────
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    setCors();
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonError('Method not allowed', 405);

    $body = json_decode(file_get_contents('php://input'), true);
    if (!$body) jsonError('Invalid JSON');

    $cfg = require __DIR__ . '/config.php';

    if (isset($body['assessment_id'])) {
        $data = loadAssessmentData((int)$body['assessment_id']);
    } else {
        $data = $body['data'] ?? null;
    }

    if (!$data) jsonError('لا توجد بيانات للتحليل');

    $result = runGeminiAnalysis($data, $cfg);
    jsonOut($result);
}

// ============================================================
function loadAssessmentData(int $id): ?array {
    $db = getDB();

    $stmt = $db->prepare('SELECT a.*, l.* FROM assessments a LEFT JOIN leads l ON a.lead_id=l.id WHERE a.id=?');
    $stmt->execute([$id]);
    $assessment = $stmt->fetch();
    if (!$assessment) return null;

    $stmt = $db->prepare('SELECT question_key, answer FROM answers WHERE assessment_id=?');
    $stmt->execute([$id]);
    $answers = [];
    foreach ($stmt->fetchAll() as $row) {
        $dec = json_decode($row['answer'], true);
        $answers[$row['question_key']] = $dec !== null ? $dec : $row['answer'];
    }

    return array_merge($assessment, ['answers' => $answers]);
}

// ============================================================
function runGeminiAnalysis(array $data, array $cfg): array {
    $priority = $cfg['analysis']['ai_priority'] ?? ['gemini', 'groq', 'nvidia', 'deepseek'];

    foreach ($priority as $provider) {
        try {
            $result = callAIProvider($provider, $data, $cfg);
            if (!empty($result['summary'])) return $result;
        } catch (\Throwable $e) {
            // جرّب المزود التالي
            continue;
        }
    }

    return fallbackAnalysis($data);
}

// ============================================================
function callAIProvider(string $provider, array $data, array $cfg): array {
    $prompt = buildPrompt($data);

    return match($provider) {
        'pekpik'          => callPekpik($prompt, $data, $cfg),
        'gemini'          => callGemini($prompt, $data, $cfg),
        'groq'            => callGroq($prompt, $data, $cfg),
        'deepseek'        => callDeepSeek($prompt, $data, $cfg),
        'openai'          => callOpenAI($prompt, $data, $cfg),
        'nvidia'          => callNvidia($prompt, $data, $cfg),
        'qwen'            => callQwen($prompt, $data, $cfg),
        'gptoss'          => callGPTOSS($prompt, $data, $cfg),
        'nemotron'        => callNemotron($prompt, $data, $cfg),       // NVIDIA 253B
        'deepseek_r1'     => callDeepSeekR1Nvidia($prompt, $data, $cfg), // DeepSeek R1 671B
        'qwen3_235b'      => callQwen3_235B($prompt, $data, $cfg),     // Qwen3 235B
        'llama_405b'      => callLlama405B($prompt, $data, $cfg),      // Llama 3.1 405B
        default           => throw new \Exception("Unknown provider: {$provider}"),
    };
}

// ── Pekpik (OpenAI-Compatible) ────────────────────────────────
// الأولوية: flagship (GPT+Claude) → gemini-pro → gemini-flash → deepseek
function callPekpik(string $prompt, array $data, array $cfg): array {
    $baseUrl = $cfg['apis']['pekpik_base_url'] ?? 'https://aiapiv2.pekpik.com/v1';

    // 1) flagship-chat = GPT-5.4 + Claude تناوب تلقائي
    foreach ($cfg['apis']['pekpik_flagship_keys'] ?? [] as $key) {
        $result = _pekpikCall($baseUrl, $key, 'flagship-chat', $prompt);
        if ($result) return parseAIResponse($result, 'pekpik_flagship');
    }

    // 2) gemini-2.5-pro
    foreach ($cfg['apis']['pekpik_pro_keys'] ?? [] as $key) {
        $result = _pekpikCall($baseUrl, $key, 'gemini-2.5-pro', $prompt);
        if ($result) return parseAIResponse($result, 'pekpik_pro');
    }

    // 3) gemini-2.5-flash
    foreach ($cfg['apis']['pekpik_gemini_keys'] ?? [] as $key) {
        $result = _pekpikCall($baseUrl, $key, 'gemini-2.5-flash', $prompt);
        if ($result) return parseAIResponse($result, 'pekpik_flash');
    }

    // 4) deepseek-chat
    foreach ($cfg['apis']['pekpik_keys'] ?? [] as $key) {
        $result = _pekpikCall($baseUrl, $key, 'deepseek-chat', $prompt);
        if ($result) return parseAIResponse($result, 'pekpik_deepseek');
    }

    throw new \Exception('All Pekpik keys failed or expired — يحتاج تجديد المفاتيح');
}

function _pekpikCall(string $baseUrl, string $key, string $model, string $prompt): ?array {
    $body = json_encode([
        'model'    => $model,
        'messages' => [
            ['role' => 'system', 'content' => 'أنت خبير تسويق رقمي. أجب دائماً بـ JSON صحيح فقط بدون أي نص إضافي.'],
            ['role' => 'user',   'content' => $prompt],
        ],
        'temperature'     => 0.7,
        'max_tokens'      => 2048,
        'response_format' => ['type' => 'json_object'],
    ]);

    $ch = curl_init($baseUrl . '/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            "Authorization: Bearer {$key}",
        ],
        CURLOPT_POSTFIELDS     => $body,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $resp     = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if (!$resp || $httpCode === 429 || $httpCode >= 400) return null;

    $decoded = json_decode($resp, true);
    $text    = $decoded['choices'][0]['message']['content'] ?? '';
    if (!$text) return null;

    $text   = preg_replace('/^```json\s*|^```\s*|```\s*$/m', '', trim($text));
    $aiData = json_decode($text, true);
    return is_array($aiData) ? $aiData : null;
}

// ── Gemini (مدوّر بين 6 مفاتيح) ─────────────────────────────
function callGemini(string $prompt, array $data, array $cfg): array {
    $keys  = $cfg['apis']['gemini_keys'] ?? [$cfg['apis']['gemini_key'] ?? ''];
    $model = $cfg['apis']['gemini_model'] ?? 'gemini-2.0-flash';

    // حاول كل مفتاح
    foreach ($keys as $key) {
        if (!$key || str_contains($key, 'YOUR')) continue;

        $url  = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$key}";
        $body = [
            'contents' => [['parts' => [['text' => $prompt]]]],
            'generationConfig' => [
                'temperature'      => 0.7,
                'maxOutputTokens'  => 2048,
                'responseMimeType' => 'application/json',
            ],
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 25,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS     => json_encode($body),
            CURLOPT_SSL_VERIFYPEER => false,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if (!$response || $httpCode === 429) continue; // rate limit — جرّب المفتاح التالي
        if ($httpCode >= 400) continue;

        $decoded = json_decode($response, true);
        $text    = $decoded['candidates'][0]['content']['parts'][0]['text'] ?? '';
        if (!$text) continue;

        $text    = preg_replace('/^```json\s*|^```\s*|```\s*$/m', '', trim($text));
        $aiData  = json_decode($text, true);
        if (!is_array($aiData)) continue;

        return parseAIResponse($aiData, 'gemini');
    }

    throw new \Exception('All Gemini keys failed');
}

// ── Groq AI (سريع جداً) ─────────────────────────────────────
function callGroq(string $prompt, array $data, array $cfg): array {
    $key   = $cfg['apis']['groq_key']   ?? '';
    $model = $cfg['apis']['groq_model'] ?? 'llama-3.3-70b-versatile';
    if (!$key) throw new \Exception('No Groq key');

    $messages = [
        ['role' => 'system', 'content' => 'أنت خبير تسويق رقمي. أجب دائماً بـ JSON صحيح فقط بدون أي نص إضافي.'],
        ['role' => 'user',   'content' => $prompt],
    ];

    $body = json_encode([
        'model'       => $model,
        'messages'    => $messages,
        'temperature' => 0.7,
        'max_tokens'  => 2048,
        'response_format' => ['type' => 'json_object'],
    ]);

    $ch = curl_init('https://api.groq.com/openai/v1/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            "Authorization: Bearer {$key}",
        ],
        CURLOPT_POSTFIELDS     => $body,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if (!$response || $httpCode >= 400) throw new \Exception("Groq failed: {$httpCode}");

    $decoded = json_decode($response, true);
    $text    = $decoded['choices'][0]['message']['content'] ?? '';
    $aiData  = json_decode($text, true);
    if (!is_array($aiData)) throw new \Exception('Groq: invalid JSON response');

    return parseAIResponse($aiData, 'groq');
}

// ── DeepSeek (Fallback) ──────────────────────────────────────
function callDeepSeek(string $prompt, array $data, array $cfg): array {
    $key   = $cfg['apis']['deepseek_key']   ?? '';
    $model = $cfg['apis']['deepseek_model'] ?? 'deepseek-chat';
    if (!$key) throw new \Exception('No DeepSeek key');

    $messages = [
        ['role' => 'system', 'content' => 'You are an expert Arabic digital marketing analyst. Always respond with valid JSON only.'],
        ['role' => 'user', 'content'   => $prompt],
    ];

    $body = json_encode(['model' => $model, 'messages' => $messages, 'temperature' => 0.7, 'max_tokens' => 2048]);

    $ch = curl_init('https://api.deepseek.com/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', "Authorization: Bearer {$key}"],
        CURLOPT_POSTFIELDS     => $body,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if (!$response || $httpCode >= 400) throw new \Exception("DeepSeek failed: {$httpCode}");

    $decoded = json_decode($response, true);
    $text    = $decoded['choices'][0]['message']['content'] ?? '';
    $text    = preg_replace('/^```json\s*|```\s*$/m', '', trim($text));
    $aiData  = json_decode($text, true);
    if (!is_array($aiData)) throw new \Exception('DeepSeek: invalid JSON');

    return parseAIResponse($aiData, 'deepseek');
}

// ── OpenAI (Fallback) ─────────────────────────────────────────
function callOpenAI(string $prompt, array $data, array $cfg): array {
    $key   = $cfg['apis']['openai_key']   ?? '';
    $model = $cfg['apis']['openai_model'] ?? 'gpt-4o-mini';
    if (!$key) throw new \Exception('No OpenAI key');

    $messages = [
        ['role' => 'system', 'content' => 'You are an expert Arabic digital marketing analyst. Always respond with valid JSON only.'],
        ['role' => 'user', 'content'   => $prompt],
    ];

    $body = json_encode(['model' => $model, 'messages' => $messages, 'temperature' => 0.7, 'max_tokens' => 2048, 'response_format' => ['type' => 'json_object']]);

    $ch = curl_init('https://api.openai.com/v1/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', "Authorization: Bearer {$key}"],
        CURLOPT_POSTFIELDS     => $body,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if (!$response || $httpCode >= 400) throw new \Exception("OpenAI failed: {$httpCode}");

    $decoded = json_decode($response, true);
    $text    = $decoded['choices'][0]['message']['content'] ?? '';
    $aiData  = json_decode($text, true);
    if (!is_array($aiData)) throw new \Exception('OpenAI: invalid JSON');

    return parseAIResponse($aiData, 'openai');
}

// ── NVIDIA Llama 4 Maverick (Backup) ──────────────────────────
function callNvidia(string $prompt, array $data, array $cfg): array {
    $key   = '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';
    $model = 'meta/llama-4-maverick-17b-128e-instruct';

    $messages = [
        ['role' => 'system', 'content' => 'أنت خبير تسويق رقمي محترف. أجب دائماً بـ JSON صحيح فقط باللغة العربية.'],
        ['role' => 'user',   'content' => $prompt],
    ];

    $body = json_encode([
        'model'       => $model,
        'messages'    => $messages,
        'temperature' => 0.7,
        'max_tokens'  => 2048,
        'stream'      => false
    ]);

    $ch = curl_init('https://integrate.api.nvidia.com/v1/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 35,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            "Authorization: Bearer {$key}",
            'Accept: application/json'
        ],
        CURLOPT_POSTFIELDS     => $body,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if (!$response || $httpCode >= 400) throw new \Exception("NVIDIA failed: {$httpCode}");

    $decoded = json_decode($response, true);
    $text    = $decoded['choices'][0]['message']['content'] ?? '';
    
    // Clean JSON markdown if present
    $text    = preg_replace('/^```json\s*|^```\s*|```\s*$/m', '', trim($text));
    $aiData  = json_decode($text, true);
    if (!is_array($aiData)) throw new \Exception('NVIDIA: invalid JSON');

    return parseAIResponse($aiData, 'nvidia');
}

// ── NVIDIA Qwen 3.5 (Reasoning Mode) ──────────────────────────
function callQwen(string $prompt, array $data, array $cfg): array {
    $key   = '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';
    $model = 'qwen/qwen3.5-122b-a10b';

    $messages = [
        ['role' => 'system', 'content' => 'أنت خبير تحليل منطقي واستراتيجي. أجب دائماً بـ JSON صحيح فقط باللغة العربية.'],
        ['role' => 'user',   'content' => $prompt],
    ];

    $body = json_encode([
        'model'       => $model,
        'messages'    => $messages,
        'temperature' => 0.6,
        'max_tokens'  => 4096,
        'stream'      => false,
        'chat_template_kwargs' => ['enable_thinking' => true]
    ]);

    $ch = curl_init('https://integrate.api.nvidia.com/v1/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 60, // Qwen thinking takes more time
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            "Authorization: Bearer {$key}",
            'Accept: application/json'
        ],
        CURLOPT_POSTFIELDS     => $body,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if (!$response || $httpCode >= 400) throw new \Exception("Qwen failed: {$httpCode}");

    $decoded = json_decode($response, true);
    $text    = $decoded['choices'][0]['message']['content'] ?? '';
    
    // Clean JSON markdown if present
    $text    = preg_replace('/^```json\s*|^```\s*|```\s*$/m', '', trim($text));
    $aiData  = json_decode($text, true);
    if (!is_array($aiData)) throw new \Exception('Qwen: invalid JSON');

    return parseAIResponse($aiData, 'qwen');
}

// ── NVIDIA GPT-OSS-120B (Decision Engine) ─────────────────────
function callGPTOSS(string $prompt, array $data, array $cfg): array {
    $key   = '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';
    $model = 'openai/gpt-oss-120b';

    $messages = [
        ['role' => 'system', 'content' => 'أنت خبير استراتيجي أول. أجب دائماً بـ JSON صحيح فقط باللغة العربية.'],
        ['role' => 'user',   'content' => $prompt],
    ];

    $body = json_encode([
        'model'       => $model,
        'messages'    => $messages,
        'temperature' => 0.7,
        'max_tokens'  => 4096,
        'stream'      => false
    ]);

    $ch = curl_init('https://integrate.api.nvidia.com/v1/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 45,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            "Authorization: Bearer {$key}",
            'Accept: application/json'
        ],
        CURLOPT_POSTFIELDS     => $body,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if (!$response || $httpCode >= 400) throw new \Exception("GPT-OSS failed: {$httpCode}");

    $decoded = json_decode($response, true);
    $text    = $decoded['choices'][0]['message']['content'] ?? '';
    
    // Clean JSON markdown if present
    $text    = preg_replace('/^```json\s*|^```\s*|```\s*$/m', '', trim($text));
    $aiData  = json_decode($text, true);
    if (!is_array($aiData)) throw new \Exception('GPT-OSS: invalid JSON');

    return parseAIResponse($aiData, 'gptoss');
}

// ── NVIDIA Helper — نداء موحد لكل موديلات NVIDIA ─────────────
function _nvidiaCall(string $key, string $model, string $prompt, int $timeout = 50, bool $thinking = false): array {
    $messages = [
        ['role' => 'system', 'content' => 'أنت خبير تسويق رقمي متخصص في السوق العربي. أجب دائماً بـ JSON صحيح فقط باللغة العربية بدون أي نص خارجه.'],
        ['role' => 'user',   'content' => $prompt],
    ];

    $payload = [
        'model'       => $model,
        'messages'    => $messages,
        'temperature' => 0.65,
        'max_tokens'  => 4096,
        'stream'      => false,
    ];
    if ($thinking) {
        $payload['chat_template_kwargs'] = ['enable_thinking' => true];
    }

    $ch = curl_init('https://integrate.api.nvidia.com/v1/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => $timeout,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            "Authorization: Bearer {$key}",
            'Accept: application/json',
        ],
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if (!$response || $httpCode >= 400) {
        throw new \Exception("NVIDIA ({$model}) failed: HTTP {$httpCode}");
    }

    $decoded = json_decode($response, true);
    $text    = $decoded['choices'][0]['message']['content'] ?? '';
    $text    = preg_replace('/^```json\s*|^```\s*|```\s*$/m', '', trim($text));
    $aiData  = json_decode($text, true);
    if (!is_array($aiData)) throw new \Exception("{$model}: invalid JSON response");
    return $aiData;
}

// ── NVIDIA Nemotron Ultra 253B — أقوى موديل NVIDIA الخاص ──────
function callNemotron(string $prompt, array $data, array $cfg): array {
    $key = $cfg['apis']['nvidia_keys']['nemotron']
        ?? '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';
    $aiData = _nvidiaCall($key, 'nvidia/llama-3.1-nemotron-ultra-253b-v1', $prompt, 60);
    return parseAIResponse($aiData, 'nemotron_253b');
}

// ── DeepSeek R1 671B عبر NVIDIA — نموذج Reasoning عملاق ──────
function callDeepSeekR1Nvidia(string $prompt, array $data, array $cfg): array {
    $key = $cfg['apis']['nvidia_keys']['deepseek_r1']
        ?? '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';
    $aiData = _nvidiaCall($key, 'deepseek-ai/deepseek-r1', $prompt, 90);
    return parseAIResponse($aiData, 'deepseek_r1_671b');
}

// ── Qwen3 235B عبر NVIDIA — أحدث وأكبر موديل Qwen ───────────
function callQwen3_235B(string $prompt, array $data, array $cfg): array {
    $key = $cfg['apis']['nvidia_keys']['qwen3_235b']
        ?? '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';
    $aiData = _nvidiaCall($key, 'qwen/qwen3-235b-a22b', $prompt, 70, true);
    return parseAIResponse($aiData, 'qwen3_235b');
}

// ── Llama 3.1 405B عبر NVIDIA — أضخم Llama متاح ─────────────
function callLlama405B(string $prompt, array $data, array $cfg): array {
    $key = $cfg['apis']['nvidia_keys']['llama_405b']
        ?? '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';
    $aiData = _nvidiaCall($key, 'meta/llama-3.1-405b-instruct', $prompt, 60);
    return parseAIResponse($aiData, 'llama_405b');
}

// ── Parser موحّد لجميع مزودي AI ─────────────────────────────
function parseAIResponse(array $aiData, string $source): array {
    return [
        'source'               => $source,
        'summary'              => $aiData['summary']              ?? '',
        'strengths'            => $aiData['strengths']            ?? [],
        'weaknesses'           => $aiData['weaknesses']           ?? [],
        'recommendations'      => $aiData['recommendations']      ?? [],
        'action_week'          => $aiData['action_week']          ?? [],
        'action_month'         => $aiData['action_month']         ?? [],
        'competitor_analysis'  => $aiData['competitor_analysis']  ?? [],
        'score_insight'        => $aiData['score_insight']        ?? '',
        'competitor_note'      => $aiData['competitor_note']      ?? '',
        'ai_tier'              => $aiData['tier']                 ?? 'yellow',
        // ── الحقول الجديدة ──────────────────────────────────
        'pain_points'          => $aiData['pain_points']          ?? [],
        'market_opportunity'   => $aiData['market_opportunity']   ?? '',
        'platform_strategy'    => $aiData['platform_strategy']    ?? [],
        'ads_strategy'         => $aiData['ads_strategy']         ?? [],
        'quick_wins'           => $aiData['quick_wins']           ?? [],
        'kpis_to_track'        => $aiData['kpis_to_track']        ?? [],
    ];
}


// ============================================================
function buildPrompt(array $data): string {
    $name     = $data['full_name']    ?? $data['company_name'] ?? 'العميل';
    $company  = $data['company_name'] ?? '';
    $type     = $data['project_type'] ?? '';
    $country  = $data['country']      ?? '';
    $platform = $data['platform']     ?? '';
    $score    = $data['score']        ?? 0;
    $answers  = $data['answers']      ?? $data;

    $breakdown = '';
    if (!empty($data['breakdown'])) {
        $bd = is_string($data['breakdown']) ? json_decode($data['breakdown'], true) : $data['breakdown'];
        foreach ($bd as $k => $v) {
            $breakdown .= "- {$k}: {$v}\n";
        }
    }

    $scanInfo = '';
    if (!empty($data['scan_result'])) {
        $scan = is_string($data['scan_result']) ? json_decode($data['scan_result'], true) : $data['scan_result'];
        if (is_array($scan)) {
            $scanInfo = "**نتائج الفحص التقني التلقائي:**\n";
            $scanInfo .= "- HTTPS: " . ($scan['hasSSL'] ?? $scan['has_ssl'] ?? false ? 'نعم' : 'لا') . "\n";
            $scanInfo .= "- Facebook Pixel: " . ($scan['hasPixel'] ?? $scan['has_fb_pixel'] ?? false ? 'نعم ✅' : 'لا ❌') . "\n";
            $scanInfo .= "- Google Analytics: " . ($scan['hasGA'] ?? $scan['has_ga'] ?? false ? 'نعم ✅' : 'لا ❌') . "\n";
            $scanInfo .= "- زر واتساب: " . ($scan['hasWhatsApp'] ?? $scan['has_whatsapp'] ?? false ? 'نعم ✅' : 'لا ❌') . "\n";
            $scanInfo .= "- سرعة التحميل: " . ($scan['speedRating'] ?? $scan['speed_rating'] ?? 'غير معروف') . "\n";

            $scanInfo .= "\n**الهدف التسويقي والميزانية:**\n";
            $scanInfo .= "- الهدف التسويقي: " . ($scan['lead_objective'] ?? 'غير محدد') . "\n";
            $scanInfo .= "- الجمهور المستهدف: " . ($scan['lead_audience'] ?? 'غير محدد') . "\n";
            $scanInfo .= "- الميزانية الإعلانية: " . ($scan['lead_budget'] ?? 'غير محدد') . "\n";

            if (!empty($scan['competitor_radar'])) {
                $scanInfo .= "\n**رادار المنافسين (مستخرج من بحث جوجل):**\n";
                foreach ($scan['competitor_radar'] as $comp) {
                    $scanInfo .= "- {$comp['name']} ({$comp['url']}): {$comp['description']}\n";
                }
            }

            // TikTok & Twitter
            if (!empty($scan['tiktok']) && ($scan['tiktok']['success'] ?? false)) {
                $tk = $scan['tiktok'];
                $scanInfo .= "\n**بيانات TikTok:**\n";
                $scanInfo .= "- المتابعون: " . ($tk['followers'] ?? '0') . "\n";
                $scanInfo .= "- الإعجابات: " . ($tk['likes'] ?? '0') . "\n";
                $scanInfo .= "- الفيديوهات: " . ($tk['video_count'] ?? '0') . "\n";
                if (!empty($tk['bio'])) $scanInfo .= "- الوصف: {$tk['bio']}\n";
            }
            if (!empty($scan['twitter']) && ($scan['twitter']['success'] ?? false)) {
                $tw = $scan['twitter'];
                $scanInfo .= "\n**بيانات Twitter (X):**\n";
                $scanInfo .= "- المتابعون: " . ($tw['followers'] ?? '0') . "\n";
                $scanInfo .= "- التغريدات: " . ($tw['posts_count'] ?? '0') . "\n";
                $scanInfo .= "- الموقع: " . ($tw['location'] ?? 'غير محدد') . "\n";
                if (!empty($tw['bio'])) $scanInfo .= "- الوصف: {$tw['bio']}\n";
            }
        }
    }

    // بيانات الإجابات
    $answersText = '';
    $labelMap = [
        'brand_logo_ready'      => 'لديه شعار وألوان',
        'brand_message_clear'   => 'رسالة تسويقية واضحة',
        'brand_guidelines'      => 'دليل Guidelines',
        'content_strategy'      => 'استراتيجية المحتوى',
        'content_frequency'     => 'قطع محتوى/أسبوع',
        'platforms_active'      => 'المنصات النشطة',
        'ads_running'           => 'يطلق إعلانات',
        'pixel_setup'           => 'Pixel مثبت',
        'ads_objective'         => 'هدف إعلاني واضح',
        'retargeting_campaigns' => 'حملات Retargeting',
        'ad_budget'             => 'ميزانية الإعلانات',
        'landing_page_exists'   => 'لديه صفحة هبوط',
        'offer_clarity'         => 'عرض لا يُقاوم',
        'checkout_friction'     => 'سهولة الشراء',
        'email_marketing'       => 'إيميل/SMS تسويقي',
        'reviews_collected'     => 'جمع تقييمات',
        'analytics_installed'   => 'Analytics مثبت',
        'kpis_tracked'          => 'يتابع مؤشرات الأداء',
        'ltv_known'             => 'يعرف LTV العميل',
    ];
    foreach ($labelMap as $key => $label) {
        $val = $answers[$key] ?? null;
        if ($val !== null) {
            if (is_bool($val)) $answersText .= "- {$label}: " . ($val ? 'نعم ✅' : 'لا ❌') . "\n";
            elseif (is_array($val)) $answersText .= "- {$label}: " . implode('، ', $val) . "\n";
            else $answersText .= "- {$label}: {$val}\n";
        }
    }

    return <<<PROMPT
═══════════════════════════════════════════════════════════════════
                    🧠 مهمتك كخبير تسويق رقمي
═══════════════════════════════════════════════════════════════════

أنت د. التسويق الرقمي — مستشار استراتيجي يعمل مع كبرى الشركات في الشرق الأوسط 
بخبرة 15+ سنة. لديك الآن بيانات حقيقية لعميل، مهمتك:

1. تشخيص وضعه بدقة جراحية
2. كشف الألم الحقيقي (ما يخسره كل يوم بسبب هذا الوضع)
3. تقديم خطة نمو متكاملة قابلة للتنفيذ فعلياً
4. إعطاء خارطة طريق 30 يوم يومية بالتفصيل الكامل

═══════════════════════════════════════════════════════════════════
                    📊 بيانات العميل الكاملة
═══════════════════════════════════════════════════════════════════

🏢 معلومات النشاط:
- الاسم: {$name}
- الشركة/النشاط: {$company}
- نوع المشروع: {$type}
- الدولة/السوق: {$country}
- المنصة الرئيسية: {$platform}

📈 نتائج الفحص الشامل:
- الدرجة الإجمالية: {$score}/100
- تحليل المحاور:
{$breakdown}

{$scanInfo}

📝 إجابات الاستبيان:
{$answersText}

═══════════════════════════════════════════════════════════════════
         📋 المطلوب: تقرير JSON شامل بالهيكل التالي تماماً
═══════════════════════════════════════════════════════════════════

{
  "summary": "خلاصة تنفيذية قوية ومخصصة بـ 4-5 جمل تصف الوضع الحالي بصدق ودقة، تذكر المنصة والسوق والفرص الضائعة",

  "pain_points": [
    "وصف مؤلم ودقيق لما يخسره العميل كل يوم بسبب غياب الاستراتيجية — اذكر أرقاماً تقريبية للخسارة",
    "الجمهور الذي يذهب للمنافسين بسبب ضعف الحضور أو المحتوى",
    "الفرصة السوقية التي تمر من أمامه دون استغلال",
    "الثقة المفقودة من العملاء المحتملين بسبب الوضع الحالي"
  ],

  "score_insight": "تعليق دقيق ومحدد على الدرجة {$score}/100: أين يقع مقارنة بمتوسط السوق في {$type} بـ{$country}؟ كيف يؤثر هذا على عائد الاستثمار التسويقي؟",

  "tier": "red|yellow|green",

  "market_opportunity": "وصف الفرصة الحقيقية المتاحة في السوق الآن لهذا النشاط في {$country} — حجم السوق، الاتجاهات، النافذة المفتوحة",

  "strengths": [
    "نقطة قوة 1 — محددة ومبنية على البيانات الفعلية",
    "نقطة قوة 2 — مع شرح كيف تُستغل",
    "نقطة قوة 3",
    "نقطة قوة 4",
    "نقطة قوة 5"
  ],

  "weaknesses": [
    "نقطة ضعف 1 — مع تأثيرها المباشر على الأرباح",
    "نقطة ضعف 2 — مع تقدير الخسارة اليومية/الشهرية",
    "نقطة ضعف 3",
    "نقطة ضعف 4",
    "نقطة ضعف 5"
  ],

  "recommendations": [
    {
      "title": "عنوان التوصية — يجب أن يكون مثيراً وعملياً",
      "priority": "عاجل|مهم|اختياري",
      "impact": "عالي|متوسط|منخفض",
      "why_now": "لماذا هذا مهم الآن تحديداً؟ ما الذي يحدث إذا تأجل؟",
      "bullets": [
        "خطوة 1 — محددة بالأداة والطريقة والوقت المطلوب",
        "خطوة 2 — مع مثال عملي من نفس القطاع",
        "خطوة 3 — قابلة للتنفيذ فورياً",
        "خطوة 4",
        "خطوة 5"
      ],
      "tools": ["أداة 1", "أداة 2"],
      "budget_needed": "التكلفة التقريبية",
      "roi": "النتيجة المتوقعة خلال 30 يوم مع أرقام تقريبية"
    },
    {
      "title": "توصية 2",
      "priority": "عاجل",
      "impact": "عالي",
      "why_now": "السبب العاجل",
      "bullets": ["خطوة 1", "خطوة 2", "خطوة 3", "خطوة 4"],
      "tools": ["أداة 1"],
      "budget_needed": "التكلفة",
      "roi": "العائد المتوقع"
    },
    {
      "title": "توصية 3",
      "priority": "مهم",
      "impact": "عالي",
      "why_now": "السبب",
      "bullets": ["خطوة 1", "خطوة 2", "خطوة 3", "خطوة 4"],
      "tools": ["أداة 1", "أداة 2"],
      "budget_needed": "التكلفة",
      "roi": "العائد"
    },
    {
      "title": "توصية 4",
      "priority": "مهم",
      "impact": "متوسط",
      "why_now": "السبب",
      "bullets": ["خطوة 1", "خطوة 2", "خطوة 3"],
      "tools": ["أداة 1"],
      "budget_needed": "التكلفة",
      "roi": "العائد"
    },
    {
      "title": "توصية 5",
      "priority": "اختياري",
      "impact": "متوسط",
      "why_now": "السبب",
      "bullets": ["خطوة 1", "خطوة 2", "خطوة 3"],
      "tools": ["أداة 1"],
      "budget_needed": "التكلفة",
      "roi": "العائد"
    }
  ],

  "competitor_analysis": [
    {
      "name": "اسم المنافس الأقوى في {$type} بـ{$country} (من بيانات الرادار فقط، لا تخترع)",
      "strength": "ما الذي يفعله جيداً؟",
      "weakness": "نقطة ضعفه التي يمكن استغلالها",
      "strategy": "استراتيجيته التسويقية الحالية",
      "how_to_beat": "كيف نتفوق عليه تحديداً بخطوات واضحة",
      "time_to_beat": "كم يستغرق التفوق عليه واقعياً"
    }
  ],

  "platform_strategy": {
    "primary_platform": "المنصة الأهم لهذا النشاط في {$country}",
    "content_pillars": ["ركيزة محتوى 1", "ركيزة 2", "ركيزة 3"],
    "posting_frequency": "كم منشور يومياً/أسبوعياً ومتى؟",
    "content_mix": "30% فيديو، 40% صور، 30% ريلز — مثال لنوع المحتوى الأنسب",
    "hashtag_strategy": "استراتيجية الهاشتاقات المناسبة",
    "growth_tactic": "أسرع تكتيك لنمو المتابعين في الفترة القادمة"
  },

  "ads_strategy": {
    "recommended_budget_distribution": "كيف يوزع الميزانية الإعلانية؟",
    "first_campaign": "أول حملة يجب إطلاقها وهدفها ومحتواها",
    "target_audience_description": "وصف الجمهور المثالي بالتفصيل",
    "ad_creatives_ideas": ["فكرة إعلان 1", "فكرة إعلان 2", "فكرة إعلان 3"],
    "retargeting_plan": "خطة Retargeting بعد الحملة الأولى"
  },

  "action_week": [
    "الخطوة العاجلة الأولى — خلال 24 ساعة",
    "الخطوة الثانية — خلال 3 أيام",
    "الخطوة الثالثة — نهاية الأسبوع"
  ],

  "action_month": {
    "week1": {
      "theme": "عنوان الأسبوع الأول",
      "goals": ["الهدف الرئيسي"],
      "tasks": [
        "المهمة الاستراتيجية الأولى",
        "المهمة الاستراتيجية الثانية",
        "مراجعة وقياس الأداء"
      ],
      "kpi": "مؤشر القياس"
    },
    "week2": {
      "theme": "عنوان الأسبوع الثاني",
      "goals": ["الهدف الرئيسي"],
      "tasks": [
        "المهمة الرئيسية 1",
        "المهمة الرئيسية 2",
        "تقييم الأسبوع"
      ],
      "kpi": "مؤشر القياس"
    },
    "week3": {
      "theme": "عنوان الأسبوع الثالث",
      "goals": ["الهدف الرئيسي"],
      "tasks": [
        "المهمة الرئيسية 1",
        "المهمة الرئيسية 2",
        "تحسين الأداء"
      ],
      "kpi": "مؤشر القياس"
    },
    "week4": {
      "theme": "عنوان الأسبوع الرابع",
      "goals": ["الهدف الرئيسي"],
      "tasks": [
        "المهمة الختامية 1",
        "إطلاق وتوسيع",
        "قياس المحصلة النهائية للشهر"
      ],
      "kpi": "النتيجة المتوقعة"
    },
    "expected_results": "النتيجة المتوقعة بعد 30 يوم؟"
  },

  "quick_wins": [
    "إنجاز سريع يمكن تحقيقه خلال 24 ساعة مع تأثير مباشر",
    "إنجاز سريع 2 — خلال 48 ساعة",
    "إنجاز سريع 3"
  ],

  "kpis_to_track": [
    {"metric": "مؤشر قياس 1", "current": "الوضع الحالي", "target_30d": "الهدف بعد 30 يوم", "how_to_measure": "كيف تقيسه؟"}
  ],

  "score_insight": "تحليل عميق للدرجة {$score}/100: الوضع مقارنة بالسوق، ما الذي يرفعها بشكل أسرع، والنتيجة المتوقعة بعد تطبيق الخطة"
}

═══════════════════════════════════════════════════════════════════
                    ⚡ تعليمات الإخراج المطلقة — (بيانات حقيقية 100%)
═══════════════════════════════════════════════════════════════════

1. ❌ ممنوع منعاً باتاً: أي نص خارج الـ JSON — حتى كلمة واحدة.
2. ❌ ممنوع التخمين أو اختراع بيانات وهمية. استخدم البيانات المتوفرة في قسم (نتائج الفحص الشامل) و(إجابات الاستبيان) حصراً.
3. ✅ بالنسبة للمنافسين (competitor_analysis): استخدم الأسماء الموجودة في (رادار المنافسين) فقط. إن لم يوجد رادار، اترك القائمة فارغة [].
4. ✅ إذا كان أي مقياس (مثل الميزانية، الجمهور) غير محدد في البيانات، اكتب "غير متوفر" ولا تتخيل أرقاماً.
5. ✅ التوصيات والخطة يجب أن تكون مبنية على "نقاط الضعف" الحقيقية المكتشفة في فحص الموقع (مثل غياب الـ Pixel أو بطء السرعة) أو ضعف منصات التواصل المرفقة، وليس نصائح عامة.
6. ✅ اجعل لغة التقرير تخاطب صاحب النشاط مباشرة — "أنت الآن..." "نشاطك يخسر..."
7. ✅ كل توصية يجب أن تكون مخصصة 100% لنوع النشاط ({$type}) في ({$country}).
8. ✅ أكمل الـ JSON الكامل بدون اختصار أي حقل.
PROMPT;
}

// ============================================================
function fallbackAnalysis(array $data): array {
    $score = (int)($data['score'] ?? 50);
    $type  = $data['project_type'] ?? 'نشاط تجاري';

    $tier = $score < 40 ? 'red' : ($score < 70 ? 'yellow' : 'green');

    $summaryMap = [
        'red'    => "نشاطك التجاري يملك إمكانات حقيقية، لكن يحتاج إلى تأسيس سليم في عدة محاور قبل البدء بالإعلانات أو التوسع.",
        'yellow' => "لديك أساس جيد ومحاور تسويقية تعمل، لكن 3-4 نقاط تحتاج معالجة سريعة حتى تصل للمستوى الاحترافي.",
        'green'  => "ممتاز! نشاطك مؤهل للنمو السريع. التركيز الآن على تحسين الكفاءة وتوسيع الوصول.",
    ];

    return [
        'source'     => 'fallback',
        'summary'    => $summaryMap[$tier],
        'ai_tier'    => $tier,
        'strengths'  => [
            'وجود رغبة واضحة في التطور والتحسين',
            'اتخاذ خطوة للتقييم يُظهر وعياً تسويقياً',
        ],
        'weaknesses' => [
            'بعض المحاور الأساسية تحتاج معالجة',
            'الحاجة لتوثيق الاستراتيجية التسويقية',
        ],
        'recommendations' => [
            [
                'title'   => 'ابدأ بالأساسيات التقنية',
                'priority'=> 'عاجل',
                'impact'  => 'عالي',
                'bullets' => ['تركيب Meta Pixel', 'إعداد Google Analytics 4', 'تأمين HTTPS'],
                'roi'     => 'تتبع أفضل وقرارات أذكى خلال أسبوعين',
            ],
        ],
        'action_week'  => ['مراجعة ملفات التواصل', 'تركيب أدوات التتبع', 'تحديث Bio بـ CTA واضح'],
        'action_month' => ['إطلاق خطة محتوى', 'أول حملة إعلانية', 'قياس النتائج وتحسينها'],
        'score_insight'  => "درجتك {$score}/100 تضعك في الرُبع " . ($score > 75 ? 'الأول المتقدم' : ($score > 50 ? 'الثاني' : 'الأدنى')) . " من النشاطات في قطاع {$type}.",
        'competitor_note'=> 'المنافسون الأقوى في هذا القطاع يستثمرون في المحتوى الفيديو القصير والإعلانات الممنهجة.',
    ];
}
