<?php
// ============================================================
// api/admin_users.php — إدارة العملاء (المحتملين والمشترين)
// ============================================================

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/middleware.php';

require_once __DIR__ . '/admin/middleware.php';
requireAdmin();
require_once __DIR__ . '/db.php';

try {
    $db = getDB();
    $method = $_SERVER['REQUEST_METHOD'];
    $type = isset($_GET['type']) ? $_GET['type'] : 'leads';

    if ($method === 'GET') {
        if ($type === 'buyers') {
            // جلب العملاء الذين قاموا بالشراء (من جدول orders و users)
            $stmt = $db->prepare("
                SELECT 
                    COALESCE(u.id, 0) as user_id, 
                    COALESCE(u.full_name, 'عميل غير مسجل') as full_name, 
                    COALESCE(u.email, '—') as email, 
                    COALESCE(u.phone, '—') as phone,
                    o.id as order_id, o.amount, o.status, o.payment_method, o.created_at as order_date,
                    p.name as package_name, p.slug as package_slug,
                    a.id as assessment_id
                FROM orders o
                LEFT JOIN users u ON o.user_id = u.id
                JOIN packages p ON o.package_id = p.id
                LEFT JOIN assessments a ON o.assessment_id = a.id
                ORDER BY o.created_at DESC
            ");
            $stmt->execute();
            $buyers = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['ok' => true, 'data' => $buyers], JSON_UNESCAPED_UNICODE);
        } 
        else {
            // جلب العملاء المحتملين (Leads)
            $hasCity = !empty($db->query("SHOW COLUMNS FROM leads LIKE 'city'")->fetchAll());
            $cityCol = $hasCity ? "l.city," : "'' as city,";

            $stmt = $db->prepare("
                SELECT 
                    l.id as lead_id, l.company_name, l.website_url, l.full_name, 
                    l.phone, l.project_type, $cityCol l.created_at,
                    a.id as assessment_id, a.score, a.is_unlocked
                FROM leads l
                LEFT JOIN assessments a ON a.lead_id = l.id
                ORDER BY l.created_at DESC
            ");
            $stmt->execute();
            $leads = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode(['ok' => true, 'data' => $leads], JSON_UNESCAPED_UNICODE);
        }
    } 
    else {
        throw new Exception("طريقة طلب غير مدعومة");
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}



