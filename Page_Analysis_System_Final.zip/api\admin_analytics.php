<?php
// ============================================================
// api/admin_analytics.php — جلب بيانات التحليلات المتقدمة
// ============================================================

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/middleware.php';

require_once __DIR__ . '/admin/middleware.php';
requireAdmin();
require_once __DIR__ . '/db.php';

try {
    $db = getDB();
    
    $days = $_GET['days'] ?? '30';
    $dateCondition = "";
    if ($days !== 'all') {
        $d = (int)$days;
        $dateCondition = "WHERE created_at >= DATE_SUB(NOW(), INTERVAL $d DAY)";
    }

    // 1. Average Score & Total Assessments
    $statsData = [];
    try {
        $statsData = $db->query("SELECT AVG(score) as avg_score, COUNT(*) as total_completed FROM assessments $dateCondition")->fetch(PDO::FETCH_ASSOC);
    } catch(Exception $e) {}
    
    $avgScore = round($statsData['avg_score'] ?? 0, 1);
    $totalCompleted = (int)($statsData['total_completed'] ?? 0);

    // 2. Total Leads (Started)
    $totalStarted = 0;
    try {
        $totalStarted = (int) $db->query("SELECT COUNT(*) FROM leads $dateCondition")->fetchColumn();
    } catch(Exception $e) {}

    // 3. Completion Rate
    $completionRate = 0;
    if ($totalStarted > 0) {
        $completionRate = round(($totalCompleted / $totalStarted) * 100, 1);
    }

    // 4. Orders Data
    $totalBought = 0;
    $totalVip = 0;
    try {
        $totalBought = (int) $db->query("SELECT COUNT(*) FROM orders WHERE status = 'completed'" . ($days !== 'all' ? " AND created_at >= DATE_SUB(NOW(), INTERVAL $d DAY)" : ""))->fetchColumn();
        
        $totalVip = (int) $db->query("SELECT COUNT(*) FROM orders o JOIN packages p ON o.package_id = p.id WHERE p.slug = 'vip' AND o.status = 'completed'" . ($days !== 'all' ? " AND o.created_at >= DATE_SUB(NOW(), INTERVAL $d DAY)" : ""))->fetchColumn();
    } catch(Exception $e) {}

    // 5. Tiers Distribution
    $tiers = ['green' => 0, 'yellow' => 0, 'red' => 0];
    try {
        $tierRows = $db->query("SELECT score FROM assessments $dateCondition")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($tierRows as $score) {
            $s = (int)$score;
            if ($s >= 80) $tiers['green']++;
            elseif ($s >= 50) $tiers['yellow']++;
            else $tiers['red']++;
        }
    } catch(Exception $e) {}

    // 6. Score Histogram (Bins: 0-20, 21-40, 41-60, 61-80, 81-100)
    $histogram = [0, 0, 0, 0, 0];
    try {
        // Reuse $tierRows
        foreach ($tierRows as $score) {
            $s = (int)$score;
            if ($s <= 20) $histogram[0]++;
            elseif ($s <= 40) $histogram[1]++;
            elseif ($s <= 60) $histogram[2]++;
            elseif ($s <= 80) $histogram[3]++;
            else $histogram[4]++;
        }
    } catch(Exception $e) {}

    echo json_encode([
        'ok' => true,
        'stats' => [
            'avg_score' => $avgScore,
            'completion_rate' => $completionRate
        ],
        'tiers' => $tiers,
        'histogram' => $histogram,
        'funnel' => [
            'visitors' => $totalStarted * 3 + 45, // Estimated
            'started' => $totalStarted,
            'completed' => $totalCompleted,
            'bought' => $totalBought,
            'vip' => $totalVip
        ]
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}


