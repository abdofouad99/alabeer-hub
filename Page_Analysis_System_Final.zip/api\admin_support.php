<?php
// ============================================================
// api/admin_support.php — إدارة تذاكر الدعم الفني
// ============================================================

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/middleware.php';
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once __DIR__ . '/admin/middleware.php';
requireAdmin();
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/db-migrate.php'; // Ensure table exists

try {
    $db = getDB();
    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        $stmt = $db->query("SELECT * FROM support_tickets ORDER BY created_at DESC");
        $tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stats = [
            'total' => count($tickets),
            'open' => 0,
            'pending' => 0,
            'closed' => 0
        ];

        foreach ($tickets as $t) {
            if ($t['status'] === 'open') $stats['open']++;
            if ($t['status'] === 'pending') $stats['pending']++;
            if ($t['status'] === 'closed') $stats['closed']++;
        }

        echo json_encode(['ok' => true, 'tickets' => $tickets, 'stats' => $stats], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($method === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true);
        $action = $data['_action'] ?? '';

        if ($action === 'create') {
            $full_name = trim($data['full_name'] ?? '');
            $email = trim($data['email'] ?? '');
            $phone = trim($data['phone'] ?? '');
            $subject = trim($data['subject'] ?? '');
            $message = trim($data['message'] ?? '');
            
            if (!$full_name || !$email || !$subject || !$message) {
                throw new Exception('جميع الحقول مطلوبة');
            }
            
            $db->prepare("INSERT INTO support_tickets (full_name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)")
               ->execute([$full_name, $email, $phone, $subject, $message]);
               
            echo json_encode(['ok' => true, 'message' => 'تم استلام تذكرتك بنجاح'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if ($action === 'update_status') {
            $id = (int)($data['id'] ?? 0);
            $status = $data['status'] ?? '';
            if (!$id || !$status) throw new Exception('بيانات غير مكتملة');
            
            $db->prepare("UPDATE support_tickets SET status = ? WHERE id = ?")->execute([$status, $id]);
            echo json_encode(['ok' => true, 'message' => 'تم تحديث حالة التذكرة'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if ($action === 'delete') {
            $id = (int)($data['id'] ?? 0);
            if (!$id) throw new Exception('معرف التذكرة مطلوب');
            
            $db->prepare("DELETE FROM support_tickets WHERE id = ?")->execute([$id]);
            echo json_encode(['ok' => true, 'message' => 'تم حذف التذكرة'], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    throw new Exception('طريقة طلب غير مدعومة');

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}



