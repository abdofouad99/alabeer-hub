<?php
// ============================================================
// api/admin_reports.php — جلب تقارير التحليل للوحة الإدارة
// ============================================================

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/middleware.php';
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once __DIR__ . '/admin/middleware.php';
requireAdmin();
require_once __DIR__ . '/db.php';

try {
    $db = getDB();
    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        // جلب جميع التقارير مع بيانات العميل المرتبطة بها
        $query = "
            SELECT 
                a.id, 
                a.created_at, 
                a.score, 
                a.tier, 
                a.status, 
                a.is_unlocked, 
                a.report_token,
                l.full_name, 
                l.company_name, 
                l.phone
            FROM assessments a
            LEFT JOIN leads l ON a.lead_id = l.id
            ORDER BY a.created_at DESC
        ";
        $stmt = $db->query($query);
        $reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // حساب الإحصائيات
        $total = count($reports);
        $unlocked = 0;
        $highScore = 0;
        
        foreach ($reports as $r) {
            if ($r['is_unlocked']) $unlocked++;
            if ($r['score'] >= 80) $highScore++;
        }

        echo json_encode([
            'ok' => true,
            'reports' => $reports,
            'stats' => [
                'total' => $total,
                'unlocked' => $unlocked,
                'highScore' => $highScore,
                'locked' => $total - $unlocked
            ]
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($method === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true);
        $action = $data['_action'] ?? '';

        if ($action === 'delete') {
            $id = (int)($data['id'] ?? 0);
            if (!$id) throw new Exception('معرف التقرير مطلوب');
            
            $db->prepare("DELETE FROM assessments WHERE id = ?")->execute([$id]);
            echo json_encode(['ok' => true, 'message' => 'تم حذف التقرير بنجاح'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        
        if ($action === 'unlock') {
            $id = (int)($data['id'] ?? 0);
            if (!$id) throw new Exception('معرف التقرير مطلوب');
            
            $db->prepare("UPDATE assessments SET is_unlocked = 1 WHERE id = ?")->execute([$id]);
            echo json_encode(['ok' => true, 'message' => 'تم فتح التقرير للعميل بنجاح'], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    throw new Exception('طريقة طلب غير مدعومة');

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}


