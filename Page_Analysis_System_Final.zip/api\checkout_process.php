<?php
// ============================================================
// api/checkout_process.php — معالجة عملية الدفع وتسجيل الطلب
// ============================================================

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/middleware.php';

require_once __DIR__ . '/db.php';

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("طريقة طلب غير صالحة");
    }

    $db = getDB();
    $data = json_decode(file_get_contents('php://input'), true);

    $assessmentId = isset($data['assessment_id']) ? (int)$data['assessment_id'] : 0;
    $packageSlug = isset($data['package_slug']) ? $data['package_slug'] : '';
    $paymentMethod = isset($data['payment_method']) ? $data['payment_method'] : 'card';
    
    // بيانات العميل
    $fullName      = trim($data['full_name']       ?? '');
    $email         = trim($data['email']            ?? '');
    $phone         = trim($data['phone']            ?? '');
    $couponCode    = trim(strtoupper($data['coupon_code']    ?? ''));
    $discountPct   = (int)($data['discount_percent'] ?? 0);

    if (!$packageSlug) {
        throw new Exception("معرف الباقة مفقود");
    }
    if (empty($fullName) || empty($email)) {
        throw new Exception("الاسم والبريد الإلكتروني مطلوبان لإتمام الطلب");
    }

    if (!$assessmentId) {
        // إذا لم يكن هناك ID فحص (شراء مباشر بدون تحليل مسبق)
        // إنشاء فحص وهمي لربط الطلب به
        $db->prepare("INSERT INTO assessments (score, is_unlocked, status) VALUES (0, 1, 'completed')")->execute();
        $assessmentId = $db->lastInsertId();
    }

    // إنشاء أو تحديث المستخدم
    $userId = null;
    $stmtUser = $db->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
    $stmtUser->execute([$email]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $userId = $user['id'];
        // تحديث رقم الجوال إذا كان مفقوداً
        $db->prepare("UPDATE users SET phone = ?, full_name = ? WHERE id = ?")->execute([$phone, $fullName, $userId]);
    } else {
        $db->prepare("INSERT INTO users (full_name, email, phone, password_hash) VALUES (?, ?, ?, ?)")
           ->execute([$fullName, $email, $phone, password_hash(bin2hex(random_bytes(8)), PASSWORD_DEFAULT)]);
        $userId = $db->lastInsertId();
    }

    // البحث عن الباقة للحصول على معرفها وسعرها
    $stmt = $db->prepare("SELECT id, price FROM packages WHERE slug = ? OR slug = ? LIMIT 1");
    // Fallback logic for shamel
    $slugSearch = $packageSlug === 'shamel' ? 'comprehensive' : $packageSlug;
    $stmt->execute([$packageSlug, $slugSearch]);
    $package = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$package) {
        throw new Exception("الباقة غير موجودة");
    }

    $packageId = $package['id'];
    $amount    = (float)$package['price'];

    // تطبيق الكوبون — نتحقق منه مرة أخرى في الـ Backend لمنع التلاعب
    if ($couponCode !== '') {
        $cStmt = $db->prepare("SELECT id, discount_percent, usage_limit, times_used, is_active, valid_until FROM coupons WHERE code = ? LIMIT 1");
        $cStmt->execute([$couponCode]);
        $coupon = $cStmt->fetch(PDO::FETCH_ASSOC);
        if ($coupon && $coupon['is_active']
            && (!$coupon['valid_until'] || strtotime($coupon['valid_until']) >= time())
            && (!$coupon['usage_limit']  || $coupon['times_used'] < $coupon['usage_limit'])) {
            // الكوبون صالح — تطبيق الخصم وزيادة عداد الاستخدام
            $discountPct = (int)$coupon['discount_percent'];
            $amount = round($amount * (1 - $discountPct / 100), 2);
            $db->prepare("UPDATE coupons SET times_used = times_used + 1 WHERE id = ?")->execute([$coupon['id']]);
        }
    }

    // تسجيل الطلب في قاعدة البيانات لكي يظهر في لوحة القيادة للإدارة
    $insertStmt = $db->prepare("INSERT INTO orders (user_id, assessment_id, package_id, amount, status, payment_method) VALUES (?, ?, ?, ?, 'completed', ?)");
    $insertStmt->execute([$userId, $assessmentId, $packageId, $amount, $paymentMethod]);

    // إذا كان السعر أكبر من صفر أو الباقة مدفوعة، نقوم بتحديث الفحص ليصبح unlocked وربطه بالمستخدم
    $cols = $db->query("SHOW COLUMNS FROM assessments")->fetchAll(\PDO::FETCH_COLUMN);
    $setClause = in_array('is_unlocked', $cols) ? "is_unlocked = 1, user_id = ?" : "user_id = ?";
    $db->prepare("UPDATE assessments SET $setClause WHERE id = ?")->execute([$userId, $assessmentId]);

    echo json_encode([
        'ok' => true,
        'message' => 'تم تسجيل الطلب بنجاح',
        'order_id' => $db->lastInsertId(),
        'amount' => $amount
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}

