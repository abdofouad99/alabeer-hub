<?php
// api/middleware.php

// 1. CORS Management
$allowed_domains = ['http://alabeer.local', 'https://alabeer.local', 'http://localhost'];
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';

if (in_array($origin, $allowed_domains)) {
    header("Access-Control-Allow-Origin: $origin");
} else if (!empty($origin)) {
    // Optionally block or allow specific
    // header("Access-Control-Allow-Origin: https://production-domain.com");
} else {
    // Same origin requests usually lack an Origin header, so we can emit nothing
}

header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 2. Rate Limiting (File-based fallback for high reliability)
$config = require __DIR__ . '/config.php';
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

// Clean IP for filename
$ip_clean = str_replace(['.', ':'], '_', $ip);
$rateDir = sys_get_temp_dir() . '/alabeer_rate_limits';
if (!is_dir($rateDir)) {
    @mkdir($rateDir, 0777, true);
}

$minuteFile = $rateDir . "/{$ip_clean}_min_" . date('YmdHi') . ".txt";
$hourFile   = $rateDir . "/{$ip_clean}_hour_" . date('YmdH') . ".txt";

$hitsMin  = (int)@file_get_contents($minuteFile) + 1;
$hitsHour = (int)@file_get_contents($hourFile) + 1;

@file_put_contents($minuteFile, $hitsMin);
@file_put_contents($hourFile, $hitsHour);

$maxMin  = $config['rate_limit']['max_per_minute'] ?? 10;
$maxHour = $config['rate_limit']['max_per_hour'] ?? 50;

if ($hitsMin > $maxMin || $hitsHour > $maxHour) {
    http_response_code(429);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Rate limit exceeded. Too many requests.']);
    exit;
}
