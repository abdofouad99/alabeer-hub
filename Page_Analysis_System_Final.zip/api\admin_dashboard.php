<?php
// ============================================================
// api/admin_dashboard.php — لوحة القيادة بالبيانات الحقيقية v2.0
// ============================================================

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/middleware.php';

require_once __DIR__ . '/admin/middleware.php';
requireAdmin();
require_once __DIR__ . '/db.php';

try {
    $db = getDB();

    // ── فلتر التاريخ ─────────────────────────────────────────
    $days = isset($_GET['days']) ? (int)$_GET['days'] : 0;
    $dateWhere  = $days > 0 ? "WHERE created_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)" : '';
    $dateAnd    = $days > 0 ? "AND created_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)" : '';
    $dateAndL   = $days > 0 ? "AND l.created_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)" : '';

    // تأكد من وجود الجداول
    try { $db->query("SELECT 1 FROM orders LIMIT 1"); }
    catch (Exception $e) { require_once __DIR__ . '/db-migrate.php'; }

    // ── 1. KPIs ───────────────────────────────────────────────
    $totalLeads = 0;
    $totalScans = 0;
    $realSales  = 0;
    $realRevenue = 0.0;

    try { $totalLeads = (int)$db->query("SELECT COUNT(*) FROM leads {$dateWhere}")->fetchColumn(); } catch(Exception $e) {}
    try { $totalScans = (int)$db->query("SELECT COUNT(*) FROM assessments {$dateWhere}")->fetchColumn(); } catch(Exception $e) {}
    try {
        $sd = $db->query("SELECT COUNT(*) as c, COALESCE(SUM(amount),0) as r FROM orders WHERE status='completed' {$dateAnd}")->fetch(PDO::FETCH_ASSOC);
        $realSales   = (int)($sd['c'] ?? 0);
        $realRevenue = (float)($sd['r'] ?? 0);
    } catch(Exception $e) {}

    $avgValue = $realSales > 0 ? round($realRevenue / $realSales, 2) : 0;

    $kpis = [
        'visitors'  => max($totalLeads * 3 + 120, $totalLeads),
        'signups'   => $totalLeads,
        'analyses'  => $totalScans,
        'sales'     => $realSales,
        'revenue'   => $realRevenue,
        'avg_value' => $avgValue,
    ];

    // ── 2. Funnel ─────────────────────────────────────────────
    $vipCount = 0;
    try {
        $vipCount = (int)$db->query(
            "SELECT COUNT(*) FROM orders o JOIN packages p ON o.package_id=p.id
             WHERE p.slug='vip' AND o.status='completed' {$dateAnd}"
        )->fetchColumn();
    } catch(Exception $e) {}

    $funnel = [
        'visitors' => $kpis['visitors'],
        'signups'  => $totalLeads,
        'started'  => $totalScans,
        'bought'   => $realSales,
        'vip'      => $vipCount,
    ];

    // ── 3. Hot Leads ──────────────────────────────────────────
    $hotLeads = [];
    try {
        $rows = $db->query("
            SELECT l.full_name, l.email, l.phone,
                   a.score, a.summary, a.weaknesses, a.created_at
            FROM leads l
            JOIN assessments a ON l.id = a.lead_id
            LEFT JOIN orders o ON a.id = o.assessment_id AND o.status='completed'
            WHERE a.score < 75 AND o.id IS NULL
            {$dateAndL}
            ORDER BY a.created_at DESC LIMIT 10
        ")->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rows as $row) {
            // استخراج أول مشكلة من حقل weaknesses (JSON)
            $problem = $row['summary'] ?? '';
            if (!$problem && !empty($row['weaknesses'])) {
                $wk = json_decode($row['weaknesses'], true);
                if (is_array($wk) && !empty($wk)) {
                    $first = $wk[0];
                    $problem = is_array($first) ? ($first['title'] ?? $first['text'] ?? '') : (string)$first;
                }
            }
            if (!$problem) $problem = 'ضعف في الأداء العام يحتاج تدخلاً';

            $diff = time() - strtotime($row['created_at']);
            if ($diff < 3600)        $timeStr = 'منذ ' . round($diff/60) . ' دقيقة';
            elseif ($diff < 86400)   $timeStr = 'منذ ' . round($diff/3600) . ' ساعة';
            else                     $timeStr = 'منذ ' . round($diff/86400) . ' يوم';

            $hotLeads[] = [
                'name'    => $row['full_name'] ?: 'عميل',
                'email'   => $row['email']  ?: $row['phone'] ?: '—',
                'score'   => (int)$row['score'],
                'problem' => $problem,
                'time'    => $timeStr,
            ];
        }
    } catch(Exception $e) {}

    // ── 4. Chart — آخر 7 أيام ────────────────────────────────
    $chartDates   = [];
    $chartSignups = [];
    $chartRevenue = [];

    for ($i = 6; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-{$i} days"));
        $label = date('d/m', strtotime($date));
        $chartDates[] = $label;
        $s = 0; $r = 0.0;
        try {
            $s = (int)$db->query("SELECT COUNT(*) FROM leads WHERE DATE(created_at)='$date'")->fetchColumn();
            $r = (float)$db->query("SELECT COALESCE(SUM(amount),0) FROM orders WHERE status='completed' AND DATE(created_at)='$date'")->fetchColumn();
        } catch(Exception $e) {}
        $chartSignups[] = $s;
        $chartRevenue[] = $r;
    }

    // ── 5. Insights ───────────────────────────────────────────
    $topProjects = [];
    try {
        $topProjects = $db->query(
            "SELECT project_type, COUNT(*) as count FROM leads
             WHERE project_type IS NOT NULL AND project_type != '' {$dateAnd}
             GROUP BY project_type ORDER BY count DESC LIMIT 5"
        )->fetchAll(PDO::FETCH_ASSOC);
    } catch(Exception $e) {}

    $topPackages = [];
    try {
        $topPackages = $db->query(
            "SELECT p.name, COUNT(o.id) as count FROM orders o
             JOIN packages p ON o.package_id=p.id
             WHERE o.status='completed' {$dateAnd}
             GROUP BY p.id ORDER BY count DESC LIMIT 3"
        )->fetchAll(PDO::FETCH_ASSOC);
    } catch(Exception $e) {}

    // استخراج المشاكل من حقل weaknesses الحقيقي
    $problemMap = [];
    try {
        $wkRows = $db->query("SELECT weaknesses FROM assessments WHERE weaknesses IS NOT NULL AND score < 70 {$dateAnd} LIMIT 100")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($wkRows as $raw) {
            $arr = json_decode($raw, true);
            if (!is_array($arr)) continue;
            foreach ($arr as $item) {
                $title = is_array($item) ? ($item['title'] ?? $item['text'] ?? '') : (string)$item;
                $title = mb_substr(trim($title), 0, 60);
                if ($title) $problemMap[$title] = ($problemMap[$title] ?? 0) + 1;
            }
        }
        arsort($problemMap);
    } catch(Exception $e) {}

    // fallback إذا لم توجد بيانات weaknesses
    if (empty($problemMap)) {
        $lowSummaries = [];
        try {
            $lowSummaries = $db->query("SELECT summary FROM assessments WHERE score < 50 {$dateAnd} LIMIT 50")->fetchAll(PDO::FETCH_COLUMN);
        } catch(Exception $e) {}
        $keywords = [
            'ضعف الثقة (Social Proof)' => ['ثقة','تجارب'],
            'غياب الدعوة للإجراء (CTA)' => ['CTA','دعوة','اتصال'],
            'بطء سرعة الموقع' => ['سرعة','بطء','تحميل'],
            'مشاكل في التتبع (Pixel)' => ['Pixel','تتبع','إعلان'],
        ];
        foreach ($keywords as $label => $kws) {
            $c = 0;
            foreach ($lowSummaries as $s) {
                foreach ($kws as $kw) { if (mb_strpos($s, $kw) !== false) { $c++; break; } }
            }
            if ($c > 0) $problemMap[$label] = $c;
        }
        arsort($problemMap);
    }

    $topProblems = array_slice(
        array_map(fn($n,$c) => ['name'=>$n,'count'=>$c], array_keys($problemMap), array_values($problemMap)),
        0, 5
    );

    echo json_encode([
        'ok'      => true,
        'kpis'    => $kpis,
        'funnel'  => $funnel,
        'hot_leads' => $hotLeads,
        'chart'   => ['labels'=>$chartDates, 'signups'=>$chartSignups, 'revenue'=>$chartRevenue],
        'insights'=> ['projects'=>$topProjects, 'packages'=>$topPackages, 'problems'=>$topProblems],
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false, 'error'=>$e->getMessage()]);
}


