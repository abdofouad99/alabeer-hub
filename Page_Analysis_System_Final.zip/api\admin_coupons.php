<?php
// ============================================================
// api/admin_coupons.php — إدارة كوبونات الخصم (CRUD + تحقق)
// ============================================================

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/middleware.php';
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once __DIR__ . '/admin/middleware.php';
requireAdmin();
require_once __DIR__ . '/db.php';

try {
    $db     = getDB();
    $method = $_SERVER['REQUEST_METHOD'];

    // ── GET: جلب كل الكوبونات أو التحقق من كوبون معين ──────────
    if ($method === 'GET') {
        $code = trim($_GET['validate'] ?? '');

        if ($code !== '') {
            $stmt = $db->prepare("SELECT * FROM coupons WHERE code = ? LIMIT 1");
            $stmt->execute([$code]);
            $coupon = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$coupon) {
                echo json_encode(['ok' => false, 'error' => 'كوبون غير موجود'], JSON_UNESCAPED_UNICODE); exit;
            }
            if (!$coupon['is_active']) {
                echo json_encode(['ok' => false, 'error' => 'هذا الكوبون غير فعّال'], JSON_UNESCAPED_UNICODE); exit;
            }
            if ($coupon['valid_until'] && strtotime($coupon['valid_until']) < time()) {
                echo json_encode(['ok' => false, 'error' => 'انتهت صلاحية هذا الكوبون'], JSON_UNESCAPED_UNICODE); exit;
            }
            if ($coupon['usage_limit'] && $coupon['times_used'] >= $coupon['usage_limit']) {
                echo json_encode(['ok' => false, 'error' => 'تجاوز هذا الكوبون الحد الأقصى للاستخدام'], JSON_UNESCAPED_UNICODE); exit;
            }
            echo json_encode([
                'ok'               => true,
                'discount_percent' => (int)$coupon['discount_percent'],
                'code'             => $coupon['code'],
                'message'          => "✅ تم تطبيق خصم {$coupon['discount_percent']}%"
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        // جلب كل الكوبونات للوحة الإدارة
        $stmt    = $db->query("SELECT * FROM coupons ORDER BY created_at DESC");
        $coupons = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['ok' => true, 'coupons' => $coupons], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ── POST: جميع العمليات في كتلة واحدة ──────────────────────
    // _action: 'create' (افتراضي) | 'delete' | 'toggle'
    if ($method === 'POST') {
        $data   = json_decode(file_get_contents('php://input'), true);
        $action = $data['_action'] ?? 'create';

        // حذف
        if ($action === 'delete') {
            $id = (int)($data['id'] ?? 0);
            if (!$id) throw new Exception('معرف الكوبون مطلوب');
            $db->prepare("DELETE FROM coupons WHERE id=?")->execute([$id]);
            echo json_encode(['ok' => true, 'message' => 'تم حذف الكوبون'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        // تفعيل / تعطيل
        if ($action === 'toggle') {
            $id       = (int)($data['id'] ?? 0);
            $newState = (int)($data['is_active'] ?? 0);
            if (!$id) throw new Exception('معرف الكوبون مطلوب');
            $db->prepare("UPDATE coupons SET is_active=? WHERE id=?")->execute([$newState, $id]);
            $msg = $newState ? 'تم تفعيل الكوبون' : 'تم تعطيل الكوبون';
            echo json_encode(['ok' => true, 'message' => $msg], JSON_UNESCAPED_UNICODE);
            exit;
        }

        // إضافة كوبون جديد (create)
        $code       = strtoupper(trim($data['code'] ?? ''));
        $discount   = (int)($data['discount_percent'] ?? 0);
        $limit      = !empty($data['usage_limit']) ? (int)$data['usage_limit'] : null;
        $validUntil = !empty($data['valid_until'])  ? $data['valid_until']     : null;
        $isActive   = isset($data['is_active'])      ? (int)$data['is_active']  : 1;

        if (!$code)                            throw new Exception('كود الكوبون مطلوب');
        if ($discount < 1 || $discount > 100) throw new Exception('نسبة الخصم يجب أن تكون بين 1 و 100');

        $check = $db->prepare("SELECT id FROM coupons WHERE code = ?");
        $check->execute([$code]);
        if ($check->fetch()) throw new Exception('هذا الكود مستخدم مسبقاً');

        $stmt = $db->prepare("INSERT INTO coupons (code, discount_percent, usage_limit, valid_until, is_active) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$code, $discount, $limit, $validUntil, $isActive]);
        echo json_encode(['ok' => true, 'id' => $db->lastInsertId(), 'message' => 'تم إضافة الكوبون بنجاح'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ── PUT: تعديل كوبون موجود ───────────────────────────────────
    if ($method === 'PUT') {
        $data = json_decode(file_get_contents('php://input'), true);
        $id   = (int)($data['id'] ?? 0);
        if (!$id) throw new Exception('معرف الكوبون مطلوب');

        $discount   = (int)($data['discount_percent'] ?? 0);
        $limit      = !empty($data['usage_limit']) ? (int)$data['usage_limit'] : null;
        $validUntil = !empty($data['valid_until'])  ? $data['valid_until']     : null;
        $isActive   = isset($data['is_active'])      ? (int)$data['is_active']  : 1;

        if ($discount < 1 || $discount > 100) throw new Exception('نسبة الخصم يجب أن تكون بين 1 و 100');

        $stmt = $db->prepare("UPDATE coupons SET discount_percent=?, usage_limit=?, valid_until=?, is_active=? WHERE id=?");
        $stmt->execute([$discount, $limit, $validUntil, $isActive, $id]);
        echo json_encode(['ok' => true, 'message' => 'تم تحديث الكوبون'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ── DELETE: دعم مباشر (Hostinger يدعمه) ──────────────────────
    if ($method === 'DELETE') {
        $data = json_decode(file_get_contents('php://input'), true);
        $id   = (int)($data['id'] ?? 0);
        if (!$id) throw new Exception('معرف الكوبون مطلوب');
        $db->prepare("DELETE FROM coupons WHERE id=?")->execute([$id]);
        echo json_encode(['ok' => true, 'message' => 'تم حذف الكوبون'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    throw new Exception('طريقة طلب غير مدعومة');

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}


