<?php
// ============================================================
// api/admin_packages.php — إدارة الباقات والأسعار (CRUD)
// ============================================================

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/middleware.php';

require_once __DIR__ . '/admin/middleware.php';
requireAdmin();
require_once __DIR__ . '/db.php';

try {
    $db = getDB();
    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        // Fetch all packages
        $stmt = $db->query("SELECT * FROM packages ORDER BY price ASC");
        $packages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Decode JSON features
        foreach ($packages as &$p) {
            $p['features'] = json_decode($p['features'] ?? '[]', true);
            $p['is_active'] = (bool)$p['is_active'];
        }
        
        echo json_encode(['ok' => true, 'packages' => $packages], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($method === 'POST') {
        // Create new package
        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['name']) || empty($data['slug'])) {
            throw new Exception("بيانات غير مكتملة");
        }

        $stmt = $db->prepare("INSERT INTO packages (name, slug, price, features, is_active) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $data['name'],
            $data['slug'],
            (float)($data['price'] ?? 0),
            json_encode($data['features'] ?? [], JSON_UNESCAPED_UNICODE),
            isset($data['is_active']) ? (int)$data['is_active'] : 1
        ]);
        
        echo json_encode(['ok' => true, 'message' => 'تم إضافة الباقة بنجاح', 'id' => $db->lastInsertId()]);
        exit;
    }

    if ($method === 'PUT') {
        // Update package
        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['id'])) {
            throw new Exception("رقم الباقة (ID) مفقود");
        }

        $stmt = $db->prepare("UPDATE packages SET name=?, slug=?, price=?, features=?, is_active=? WHERE id=?");
        $stmt->execute([
            $data['name'],
            $data['slug'],
            (float)($data['price'] ?? 0),
            json_encode($data['features'] ?? [], JSON_UNESCAPED_UNICODE),
            isset($data['is_active']) ? (int)$data['is_active'] : 1,
            (int)$data['id']
        ]);
        
        echo json_encode(['ok' => true, 'message' => 'تم تحديث الباقة بنجاح']);
        exit;
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}


