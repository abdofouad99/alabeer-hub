<?php
// ============================================================
// api/admin_vip.php — طلبات تنفيذ VIP
// ============================================================

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/middleware.php';
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once __DIR__ . '/admin/middleware.php';
requireAdmin();
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/db-migrate.php'; // Ensure table exists

try {
    $db = getDB();
    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        $stmt = $db->query("SELECT * FROM vip_requests ORDER BY created_at DESC");
        $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stats = [
            'total' => count($requests),
            'new' => 0,
            'in_progress' => 0,
            'completed' => 0
        ];

        foreach ($requests as $r) {
            if ($r['status'] === 'new') $stats['new']++;
            if ($r['status'] === 'in_progress' || $r['status'] === 'contacted') $stats['in_progress']++;
            if ($r['status'] === 'completed') $stats['completed']++;
        }

        echo json_encode(['ok' => true, 'requests' => $requests, 'stats' => $stats], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($method === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true);
        $action = $data['_action'] ?? '';

        if ($action === 'create') {
            // For future frontend integration
            $full_name = trim($data['full_name'] ?? '');
            $email = trim($data['email'] ?? '');
            $phone = trim($data['phone'] ?? '');
            $company = trim($data['company_name'] ?? '');
            $notes = trim($data['notes'] ?? '');
            
            if (!$full_name || !$phone) throw new Exception('الاسم ورقم الجوال مطلوبان');
            
            $db->prepare("INSERT INTO vip_requests (full_name, email, phone, company_name, notes) VALUES (?, ?, ?, ?, ?)")
               ->execute([$full_name, $email, $phone, $company, $notes]);
               
            echo json_encode(['ok' => true, 'message' => 'تم استلام طلبك بنجاح، سنتواصل معك قريباً'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if ($action === 'update_status') {
            $id = (int)($data['id'] ?? 0);
            $status = $data['status'] ?? '';
            if (!$id || !$status) throw new Exception('بيانات غير مكتملة');
            
            $db->prepare("UPDATE vip_requests SET status = ? WHERE id = ?")->execute([$status, $id]);
            echo json_encode(['ok' => true, 'message' => 'تم تحديث حالة الطلب'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if ($action === 'delete') {
            $id = (int)($data['id'] ?? 0);
            if (!$id) throw new Exception('معرف الطلب مطلوب');
            
            $db->prepare("DELETE FROM vip_requests WHERE id = ?")->execute([$id]);
            echo json_encode(['ok' => true, 'message' => 'تم حذف الطلب بنجاح'], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    throw new Exception('طريقة طلب غير مدعومة');

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}



