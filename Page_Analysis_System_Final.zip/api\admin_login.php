<?php
// ============================================================
// api/admin_login.php — تسجيل دخول لوحة القيادة
// ============================================================

$cfg = require __DIR__ . '/config.php';
session_name($cfg['admin']['session_name']);
session_start();

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/middleware.php';

require_once __DIR__ . '/db.php';


try {
    $db = getDB();
    
    // Check if there's any admin in admin_users, if not create a default one
    $stmt = $db->query("SELECT COUNT(*) FROM admin_users");
    if ($stmt->fetchColumn() == 0) {
        $defaultPassword = password_hash('admin123', PASSWORD_DEFAULT);
        $db->prepare("INSERT INTO admin_users (email, password_hash) VALUES (?, ?)")
           ->execute(['admin@alabeer.com', $defaultPassword]);
    }

    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data) {
        throw new Exception('لا توجد بيانات');
    }

    $email = trim($data['email'] ?? '');
    $password = $data['password'] ?? '';

    if (!$email || !$password) {
        throw new Exception('البريد الإلكتروني وكلمة المرور مطلوبان');
    }

    $stmt = $db->prepare("SELECT id, email, password_hash FROM admin_users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !password_verify($password, $user['password_hash'])) {
        throw new Exception('البريد الإلكتروني أو كلمة المرور غير صحيحة');
    }

    // Set Session
    $_SESSION['admin_id'] = $user['id'];
    $_SESSION['admin_email'] = $user['email'];

    echo json_encode([
        'ok' => true,
        'message' => 'تم تسجيل الدخول بنجاح',
        'redirect' => 'dashboard.html'
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
