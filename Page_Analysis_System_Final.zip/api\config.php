<?php
// ============================================================
// api/config.php — إعدادات النظام الكاملة v3.0 (Secured with .env)
// ============================================================

// ─── تحميل متغيرات البيئة من .env ─────────────────────────────
$envPath = __DIR__ . '/.env';
if (file_exists($envPath)) {
    $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        if (strpos($line, '=') !== false) {
            list($name, $value) = explode('=', $line, 2);
            $name = trim($name);
            $value = trim($value, " \t\n\r\0\x0B\"'");
            if (!array_key_exists($name, $_ENV)) {
                putenv(sprintf('%s=%s', $name, $value));
                $_ENV[$name] = $value;
                $_SERVER[$name] = $value;
            }
        }
    }
}

// ─── Helper: استرجاع مصفوفة من البيئة ───────────────────────
if (!function_exists('getEnvArray')) {
    function getEnvArray($key) {
        $val = getenv($key);
        if (!$val) return [];
        return array_map('trim', explode(',', $val));
    }
}

// ─── Helper: اختيار Gemini Key تلقائياً بالتناوب ────────────
if (!function_exists('getGeminiKey')) {
    function getGeminiKey(array $cfg): string {
        $keys = $cfg['apis']['gemini_keys'] ?? [];
        if (empty($keys)) return '';
        return $keys[time() % count($keys)];
    }
}

// ─── Helper: اختيار Apify Token تلقائياً بالتناوب ───────────
if (!function_exists('getApifyToken')) {
    function getApifyToken(array $cfg): string {
        $tokens = $cfg['apis']['apify_tokens'] ?? [];
        if (empty($tokens)) return '';
        return $tokens[time() % count($tokens)];
    }
}

return [

    // ─── قاعدة البيانات (Local by Flywheel) ─────────────────
    'db' => [
        'host'    => getenv('DB_HOST') ?: '127.0.0.1:10006',
        'name'    => getenv('DB_NAME') ?: 'local',
        'user'    => getenv('DB_USER') ?: 'root',
        'pass'    => getenv('DB_PASS') ?: 'root',
        'charset' => 'utf8mb4',
    ],

    // ─── Supabase (للمزامنة والنسخ الاحتياطي) ───────────────
    'supabase' => [
        'url'        => getenv('SUPABASE_URL'),
        'anon_key'   => getenv('SUPABASE_ANON_KEY'),
        'secret_key' => getenv('SUPABASE_SECRET_KEY'),
        'db_url'     => getenv('SUPABASE_DB_URL'),
    ],

    // ─── Admin ───────────────────────────────────────────────
    'admin' => [
        'session_name'     => 'alabeer_admin_sess',
        'session_lifetime' => 7200,
    ],

    // ─── App Settings ────────────────────────────────────────
    'app' => [
        'wa_number' => '967739537053',
        'version'   => '3.0',
        'name'      => 'بصمة النمو — تحليل الصفحات',
    ],

    // ─── API Keys ────────────────────────────────────────────
    'apis' => [

        // ── Gemini AI (مدوّر تلقائي بين عدة مفاتيح) ───────────
        'gemini_keys'  => getEnvArray('GEMINI_KEYS'),
        // المفتاح الأساسي (يُختار تلقائياً من القائمة عادة)
        'gemini_key'   => getenv('GEMINI_KEY'),
        'gemini_model' => 'gemini-2.0-flash',

        // ── Google PageSpeed (يعمل بدون مفتاح بحد محدود) ────
        'google_pagespeed_key' => '',  // اتركه فارغاً = مجاني بدون حد عالٍ

        // ── Facebook Graph API ───────────────────────────────
        'facebook_access_token' => getenv('FACEBOOK_ACCESS_TOKEN'),
        'meta_ads_token'        => getenv('META_ADS_TOKEN'),

        // ── Apify (مدوّر تلقائي بين المفاتيح المتاحة) ────────
        'apify_tokens'          => getEnvArray('APIFY_TOKENS'),
        'apify_token'           => getenv('APIFY_TOKEN'),
        'apify_actor_fb'        => 'apify~facebook-pages-scraper',   
        'apify_actor_ads_fb'    => 'apify~facebook-ads-library-scraper', 
        'apify_actor_ads_any'   => 'JJghSZmShuco4j9gJ',   
        'apify_actor_ig'        => 'apify~instagram-profile-scraper', 
        'apify_actor_tiktok'    => 'GdWCkxBtKWOsKjdch',   
        'apify_actor_website'   => 'apify~puppeteer-scraper', 

        // ── Groq AI (سريع جداً — Fallback) ──────────────────
        'groq_key'   => getenv('GROQ_KEY'),
        'groq_model' => 'llama-3.3-70b-versatile',

        // ── OpenAI (Fallback) ─────────────────────────────────
        'openai_key'   => getenv('OPENAI_KEY'),
        'openai_model' => 'gpt-4o-mini',

        // ── DeepSeek Direct ───────────────────────────────────
        'deepseek_key'   => getenv('DEEPSEEK_KEY'),
        'deepseek_model' => 'deepseek-chat',

        // ── Pekpik (OpenAI-Compatible — مجاني، يتجدد يومياً) ─────
        'pekpik_base_url' => 'https://aiapiv2.pekpik.com/v1',

        // flagship-chat = تناوب تلقائي بين GPT-5.4 + Claude + Gemini
        'pekpik_flagship_keys'  => getEnvArray('PEKPIK_FLAGSHIP_KEYS'),
        'pekpik_flagship_model' => 'flagship-chat',

        // gemini-2.5-pro (عالي الجودة)
        'pekpik_pro_keys'       => getEnvArray('PEKPIK_PRO_KEYS'),
        'pekpik_pro_model'      => 'gemini-2.5-pro',

        // gemini-2.5-flash (سريع)
        'pekpik_gemini_keys'    => getEnvArray('PEKPIK_GEMINI_KEYS'),
        'pekpik_gemini_model'   => 'gemini-2.5-flash',

        // deepseek-chat (30 مفتاح)
        'pekpik_keys'           => getEnvArray('PEKPIK_KEYS'),
        'pekpik_model'          => 'deepseek-chat',

        // ── OpenRouter (Meta Llama / Fallback) ───────────────
        'openrouter_key' => getenv('OPENROUTER_KEY'),

        // ── Upstash Redis (Cache & Queue) ────────────────────
        'redis_url'   => getenv('REDIS_URL'),
        'redis_token' => getenv('REDIS_TOKEN'),

        // ── Supabase Keys shortcuts ───────────────────────────
        'supabase_url'    => getenv('SUPABASE_URL'),
        'supabase_anon'   => getenv('SUPABASE_ANON_KEY'),
        'supabase_secret' => getenv('SUPABASE_SECRET_KEY'),
    ],

    // ─── Rate Limiting ───────────────────────────────────────
    'rate_limit' => [
        'max_per_minute' => 10,
        'max_per_hour'   => 50,
        'max_per_day'    => 200,
    ],

    // ─── Analysis Settings ───────────────────────────────────
    'analysis' => [
        'timeout_seconds'    => 45,
        'cache_hours'        => 6,
        'enable_pagespeed'   => true,   // ✅ مفعّل
        'enable_gemini'      => true,   // ✅ مفعّل (6 مفاتيح)
        'enable_apify'       => true,   // ✅ مفعّل (6 رموز)
        'enable_instagram'   => true,   // ✅ مفعّل
        'enable_ads_library' => true,   // ✅ مفعّل (مجاني)
        'enable_groq'        => true,   // ✅ مفعّل (fallback سريع)
        'enable_cache'       => true,   // ✅ Redis cache
        // ترتيب أولوية AI: Pekpik (مجاني) → Gemini → Groq → DeepSeek
        'ai_priority' => ['pekpik', 'gemini', 'groq', 'deepseek', 'openai'],
    ],
];
