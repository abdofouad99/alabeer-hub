-- ============================================================
-- بصمة النمو | قاعدة بيانات MySQL الموحدة (schema_complete.sql)
-- ============================================================
SET NAMES utf8mb4;
SET time_zone = '+03:00';

-- ── جدول المدراء (admin_users) ──────────────────────────────────
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(191) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `admin_users` (`email`, `password_hash`) VALUES
('admin@alabeer.com', '$2y$12$LRwGEuFi/GOkBGNB3L4H4OpDAtHGEnpHX2iFELsMRaMdCkjzrBirm');

-- ── جدول العملاء (Leads) ────────────────────────────────────
CREATE TABLE IF NOT EXISTS `leads` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `full_name` VARCHAR(191),
  `phone` VARCHAR(60),
  `email` VARCHAR(191),
  `company_name` VARCHAR(191),
  `objective` VARCHAR(100),
  `target_audience` VARCHAR(150),
  `ad_budget` VARCHAR(60),
  `project_type` VARCHAR(60),
  `platform` VARCHAR(60),
  `country` VARCHAR(100),
  `city` VARCHAR(60) NULL,
  `website_url` VARCHAR(500),
  `instagram_url` VARCHAR(500),
  `tiktok_url` VARCHAR(500),
  `facebook_url` VARCHAR(500),
  `youtube_url` VARCHAR(500),
  `status` VARCHAR(30) NOT NULL DEFAULT 'new',
  `notes` TEXT,
  `source` VARCHAR(100) NOT NULL DEFAULT 'growth_fingerprint',
  PRIMARY KEY (`id`),
  KEY `idx_leads_email` (`email`),
  KEY `idx_leads_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── جدول المستخدمين العملاء (users) ───────────────────────────
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(150) NOT NULL,
  `email` VARCHAR(120) NOT NULL UNIQUE,
  `phone` VARCHAR(30),
  `password_hash` VARCHAR(255) NOT NULL DEFAULT '',
  `role` ENUM('user','admin') DEFAULT 'user',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── جدول التقييمات (assessments) ───────────────────────────
CREATE TABLE IF NOT EXISTS `assessments` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lead_id` INT UNSIGNED,
  `user_id` INT UNSIGNED NULL,
  `status` VARCHAR(30) NOT NULL DEFAULT 'submitted',
  `score` TINYINT UNSIGNED,
  `tier` VARCHAR(20),
  `breakdown` LONGTEXT COMMENT 'JSON',
  `summary` TEXT,
  `strengths` LONGTEXT COMMENT 'JSON array',
  `weaknesses` LONGTEXT COMMENT 'JSON array',
  `recommendations` LONGTEXT COMMENT 'JSON array',
  `next_steps` LONGTEXT COMMENT 'JSON array',
  `scan_result` LONGTEXT COMMENT 'JSON',
  `scan_status` VARCHAR(20),
  `scan_error` TEXT,
  `report_token` VARCHAR(64) NOT NULL DEFAULT '',
  `scan_step` VARCHAR(60),
  `is_unlocked` TINYINT(1) DEFAULT 0,
  `customer_journey` JSON NULL,
  `bottleneck` VARCHAR(255) NULL,
  `bottleneck_desc` TEXT NULL,
  `pdf_path` VARCHAR(255) NULL,
  PRIMARY KEY (`id`),
  KEY `idx_assessment_lead_id` (`lead_id`),
  KEY `idx_assessment_user_id` (`user_id`),
  KEY `idx_report_token` (`report_token`),
  CONSTRAINT `fk_assessment_lead` FOREIGN KEY (`lead_id`) REFERENCES `leads`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_assessment_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── جدول الإجابات (answers) ───────────────────────────────────
CREATE TABLE IF NOT EXISTS `answers` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `assessment_id` INT UNSIGNED NOT NULL,
  `question_key` VARCHAR(100) NOT NULL,
  `answer` LONGTEXT NOT NULL COMMENT 'JSON',
  PRIMARY KEY (`id`),
  KEY `idx_assessment_id` (`assessment_id`),
  CONSTRAINT `fk_answer_assessment` FOREIGN KEY (`assessment_id`) REFERENCES `assessments`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── جدول الباقات (packages) ───────────────────────────────────
CREATE TABLE IF NOT EXISTS `packages` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(50) NOT NULL UNIQUE,
  `price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `features` JSON,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_packages_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `packages` (`name`,`slug`,`price`,`features`) VALUES
('الباقة المجانية','free',0.00,'["تحليل سريع","الدرجة العامة","المشكلة الرئيسية"]'),
('الباقة الاحترافية','pro',10.00,'["تقرير كامل PDF","تحليل شامل","نقاط القوة والضعف","رحلة العميل","توصيات فورية","خطة أولية"]'),
('الباقة الشاملة','comprehensive',50.00,'["كل ما في الاحترافية","استشارة خاصة 60 دقيقة","خطة نمو 30 يوم","خطة إعلانات","ترتيب الأولويات","متابعة بالإيميل"]'),
('باقة VIP','vip',0.00,'["كل ما في الشاملة","تنفيذ كامل بالمؤسسة","إدارة الحساب والمحتوى","إدارة الإعلانات","تقارير دورية","دعم مخصص 24/7"]');

-- ── جدول الطلبات/المدفوعات (orders) ───────────────────────────
CREATE TABLE IF NOT EXISTS `orders` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NULL,
  `assessment_id` INT UNSIGNED NULL,
  `package_id` INT UNSIGNED NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `status` ENUM('pending','completed','failed','refunded') DEFAULT 'pending',
  `payment_method` VARCHAR(50),
  `transaction_id` VARCHAR(100),
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_orders_user_id` (`user_id`),
  KEY `idx_orders_assessment_id` (`assessment_id`),
  KEY `idx_orders_package_id` (`package_id`),
  KEY `idx_orders_status` (`status`),
  CONSTRAINT `fk_order_package` FOREIGN KEY (`package_id`) REFERENCES `packages`(`id`) ON DELETE RESTRICT,
  CONSTRAINT `fk_order_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_order_assessment` FOREIGN KEY (`assessment_id`) REFERENCES `assessments`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── جدول الكوبونات (coupons) ───────────────────────────────────
CREATE TABLE IF NOT EXISTS `coupons` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(50) NOT NULL UNIQUE,
  `discount_percent` INT NOT NULL,
  `valid_until` DATETIME,
  `usage_limit` INT,
  `times_used` INT DEFAULT 0,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_coupons_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── جدول تذاكر الدعم الفني (support_tickets) ──────────────────
CREATE TABLE IF NOT EXISTS `support_tickets` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(150) NOT NULL,
  `email` VARCHAR(120) NOT NULL,
  `phone` VARCHAR(30) NULL,
  `subject` VARCHAR(200) NOT NULL,
  `message` TEXT NOT NULL,
  `status` ENUM('open', 'pending', 'closed') DEFAULT 'open',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_support_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── جدول طلبات VIP (vip_requests) ────────────────────────────
CREATE TABLE IF NOT EXISTS `vip_requests` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(150) NOT NULL,
  `email` VARCHAR(120) NOT NULL,
  `phone` VARCHAR(30) NOT NULL,
  `company_name` VARCHAR(150) NULL,
  `notes` TEXT NULL,
  `status` ENUM('new', 'contacted', 'in_progress', 'completed', 'rejected') DEFAULT 'new',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_vip_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
