<?php
// ============================================================
// api/admin_logout.php — تسجيل خروج
// ============================================================

$cfg = require __DIR__ . '/config.php';
session_name($cfg['admin']['session_name']);
session_start();
session_unset();
session_destroy();

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => true, 'redirect' => 'login.html']);
